#!/bin/sh
KEY=$1
HOST=$2
PROXY=$3
CHAZHI=$4
yuzhi_CPU=$5
yuzhi_Exhaust=$6
yuzhi_Ambient=$7
sudo ipmitool lan print > /dev/null
a=`echo $? `
if [ $a != 0 ]
then
 echo " "
 /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 0  >/dev/null 2>&1
else
sudo /usr/bin/ipmitool  sensor  2>/dev/null > /usr/local/zabbix/tmp/check.temp.txt
TEMP=`sort -t"|" -rn -k2  /usr/local/zabbix/tmp/check.temp.txt | grep 'degrees C'|grep -Ei  "$KEY" | awk -F "|" '{print $2}'|awk '{print sprintf("%d", $0);}'|head -1`
#TEMP_TYPE=`cat /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "CPU|Exhaust|Ambient"|cat /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "$KEY"|awk -F '|' '{print $NF,$1}'|sort -k1 -rn|grep -Ei "CPU|Exhaust|Ambient"|head -1|cut -d" " -f5-|sed 's/[ \t]*$//g'`
TEMP_TYPE=`sort -t"|" -rn -k2  /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "CPU|Exhaust|Ambient"|awk -F '|' '{print $1}'|sed 's/[ \t]*$//g'|head -1`
Upper_Critical=`sudo /usr/bin/ipmitool sensor get "$TEMP_TYPE"  2>/dev/null| grep 'Upper Critical' | awk '{print $4}'|cut -d "." -f1| awk '{print sprintf("%d", $0);}'`
if [[ $Upper_Critical == " " ]] || [[ $Upper_Critical == 0 ]] || [[ $Upper_Critical -le 10 ]]
then
  if [[ `echo "$TEMP_TYPE" | grep -ic CPU` -eq 1 ]]
  then
     if [ $TEMP -ge $yuzhi_CPU ]
     then
        /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 1  >/dev/null 2>&1
     else
       /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 0  >/dev/null 2>&1
     fi
   elif [[ `echo "$TEMP_TYPE" | grep -ic Exhaust` -eq 1 ]]
     then
      if [ $TEMP -ge $yuzhi_Exhaust ]
      then
        /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 1  >/dev/null 2>&1
      else
       /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 0  >/dev/null 2>&1
      fi
   elif [[ `echo "$TEMP_TYPE" | grep -ic Ambient` -eq 1 ]]
     then
      if [ $TEMP -ge $yuzhi_Ambient ]
      then
        /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 1  >/dev/null 2>&1
      else
       /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 0  >/dev/null 2>&1
     fi
   fi
 else
JIEGUO=`echo "$Upper_Critical"-"$TEMP"|bc`
if [[ $JIEGUO -lt $CHAZHI ]]
   then
     /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 1  >/dev/null 2>&1
   else
     /usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k Temp_alarm -o 0  >/dev/null 2>&1
fi
fi
fi
echo $TEMP
/usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k TEMP_TYPE -o "$TEMP_TYPE"  >/dev/null 2>&1
