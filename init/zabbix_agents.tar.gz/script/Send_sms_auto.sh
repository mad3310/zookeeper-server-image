#!/bin/sh
cd /home/zabbix/bin
export LANG=en_US.UTF-8
Title=`echo "$1" |cut -d":" -f1|iconv -f UTF8 -t GB2312`
PHONE=`echo "$1"|grep -o -P "(\d+)"|sort|uniq|xargs`
shift
Title=`echo "$*" |iconv -f UTF8 -t GB2312`
if [ -n "$PHONE" ]
then
for SMS in $PHONE
do
./Send_sms.sh  "$SMS" "$Title" &
done
fi
