#!/bin/bash
HOST=$1
PROXY=$2
SSO_TMP=/usr/local/zabbix/tmp/sso.tmp
SSO_FILE=/usr/local/zabbix/tmp/sso.txt
CHECK_SSO_FILE=/usr/local/zabbix/tmp/sso.log
cat /dev/null > $SSO_TMP
cat /dev/null > $SSO_FILE
cat /dev/null > $CHECK_SSO_FILE
HTTP=`(time -p curl -Is -S --connect-timeout 3 'api.sso.letv.com/api/getUserByID/uid/18465293'|grep 'HTTP') 2> $SSO_TMP`
system_code=`echo $?`
if [[ `echo $HTTP` == '' ]]
 then
     echo "$HOST SSO_HTTP connection_error" > $SSO_FILE
     echo "$HOST SSO_time `cat $SSO_TMP|grep real|awk '{print $2}'`" >> $SSO_FILE
     echo "$HOST system_return_code $system_code" >> $SSO_FILE
  else
     echo "$HOST SSO_HTTP $HTTP" > $SSO_FILE
     echo "$HOST SSO_time `cat $SSO_TMP|grep real|awk '{print $2}'`" >> $SSO_FILE
     echo "$HOST system_return_code $system_code" >> $SSO_FILE
fi
if [[ -s $SSO_FILE ]]
   then
      /usr/local/zabbix/bin/zabbix_sender -z $PROXY -i $SSO_FILE 2>>$CHECK_SSO_FILE 1>>$CHECK_SSO_FILE
       Failed=`cat $CHECK_SSO_FILE|grep -c "Failed 0"`
      if [ $Failed -eq 1 ]
        then
         echo "OK"
        else
         echo "`cat $CHECK_SSO_FILE|grep Failed`"
      fi
    else
        echo "not exist"
fi
