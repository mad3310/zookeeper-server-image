#!/bin/sh
HOSTNAME=$1
PROXY_IP=$2
TOTAL_NUM=$3
cd /usr/local/zabbix/tmp
cat /dev/null > /usr/local/zabbix/tmp/codesize.log
cat /dev/null >  /usr/local/zabbix/tmp/code.temp
cat /dev/null > /usr/local/zabbix/tmp/code_new.txt
code_temp=/usr/local/zabbix/tmp/code.temp
code_txt=/usr/local/zabbix/tmp/code_new.txt
#cat /dev/null > $code_temp
#cat /dev/null > $code_txt 
if [ -r /usr/local/letv/access.log ]
then
if [ $TOTAL_NUM -gt 1000 ]
then
i=0
while (( $i < 6 ));do
tail -$TOTAL_NUM /usr/local/letv/access.log |grep -E "platid=|video_type="|grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`"  >> /usr/local/zabbix/tmp/codesize.log
i=$((i+1))
done
if [ -s /usr/local/zabbix/tmp/codesize.log ]
then
total=`wc -l /usr/local/zabbix/tmp/codesize.log| awk '{print $1}'`
rate_num=`cat /usr/local/zabbix/tmp/codesize.log|grep 'playid=0' | grep -wc "200 0"`
live_num=`cat /usr/local/zabbix/tmp/codesize.log|grep 'playid=1' | grep -wc "200 0"`
code_rate_200_0=`echo "scale=2;${rate_num}*100/${total}"|bc`
code_live_200_0=`echo "scale=2;${live_num}*100/${total}"|bc`
echo "$HOSTNAME CODE_RATE_200_0 ${code_rate_200_0}" >> $code_temp
echo "$HOSTNAME CODE_LIVE_200_0 ${code_live_200_0}" >> $code_temp

if [[ -s $code_temp ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $code_temp 2>>$code_txt 1>>$code_txt
  Failed=`cat $code_txt|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else
       echo "`cat $code_txt|grep Failed`"
     fi
else
echo "check_error"
fi
else
echo "0"
fi
else
echo "check_error"
fi
fi
