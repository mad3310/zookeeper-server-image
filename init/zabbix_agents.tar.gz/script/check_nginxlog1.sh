#!/bin/sh
FILE=$1
KEY_WORD=$2
NUM=$3
ARGNUM=$#
FILENAME=`basename $1`
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:  $0  FILE KEY_WORD NUM"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/nginxlogcheck_${FILENAME}
if [ -r ${FILE} ]
then
i=0
while (( $i < 10 ));do
tail -20000 ${FILE} | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Ei "${KEY_WORD}"   >> /tmp/nginxlogcheck_${FILENAME}
i=$((i+1))
done
if [ -s /tmp/nginxlogcheck_${FILENAME} ]&&[ `wc -l /tmp/nginxlogcheck_${FILENAME}|awk '{print $1'}` -ge $NUM ]
then
head -3 /tmp/nginxlogcheck_${FILENAME}
elif [ -w  /tmp/nginxlogcheck_${FILENAME} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi

