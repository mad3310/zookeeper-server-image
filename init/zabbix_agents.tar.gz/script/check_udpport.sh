#!/bin/bash
ARGNUM=$#
if [ $ARGNUM -ne 2 ] 
then
echo "Usage:  $0  IP PORT"
exit 0
fi
sudo /usr/bin/nmap -n -T4 -sU $1 -pU:$2|grep -q "$2\/udp\ open"
echo $?
