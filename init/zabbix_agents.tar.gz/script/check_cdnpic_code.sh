#!/bin/sh
cd /usr/local/zabbix/tmp
HOSTNAME=$1
PROXY_IP=$2
TAIL_NUM=$3
DATA_FILE=/usr/local/zabbix/tmp/cdnpic_code.txt
LOG_FILE=/usr/local/zabbix/tmp/cdnpic_code.temp
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
tail -${TAIL_NUM} /var/log/nginx/access.log|grep -E "up_status:" > /usr/local/zabbix/tmp/cdnpic_code.log
TOTAL_NUM=`wc -l /usr/local/zabbix/tmp/cdnpic_code.log|awk '{print $1}'`
if [ $TOTAL_NUM -gt 1000 ]
then
for code in 200 404 406 500 501 502 503 504 505 302
do
up_status=`grep -c "up_status:$code" /usr/local/zabbix/tmp/cdnpic_code.log`
echo "$HOSTNAME up_status$code $up_status" >> $DATA_FILE
done

if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 0 ]
     then
       echo "OK"
     else
       echo "`cat $LOG_FILE|grep Failed`"
  fi
else
    echo "Error"
fi
else
echo "less then 1000"
fi
