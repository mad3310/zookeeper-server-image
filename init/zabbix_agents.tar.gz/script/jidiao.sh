#!/bin/bash
export LANG=en_US.UTF-8
cd /usr/local/zabbix/tmp
DAY=`date +%F`
last_time=`date +%H:%M`
ago_time=`date --date='1 hours ago' +%H:%M`
file=/usr/local/zabbix/tmp/jidiao.tmp
curl -s "http://dfeed.networkbench.com/rpc-export/exportTxt.po?authkey=Gyssci6Aie&taskType=1&taskId=61243&startDate=$DAY%20$ago_time&endDate=$DAY%20$last_time&field=TM,CTN,ISN,ERN,CE"|sed 1d|awk -F "," '$(NF-1) != "\"\""' > $file
if [[ -s $file ]]
   then
     if [ `cat $file|wc -l` -ge 2 ]
        then
           echo "`cat $file|head -5|iconv -f GB2312 -t UTF8`"
        else
           echo "Check_OK"
     fi
   else
      echo "Check_OK"
fi
