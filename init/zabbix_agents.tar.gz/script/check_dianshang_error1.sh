#!/bin/sh
FILE=$1
TEMP_FILE=$2
NUM=$3
T_NUM=$4
ARGNUM=$#
FILENAME=`basename $1`
TMP_FILE=/usr/local/zabbix/tmp/dianshangcheck_${TEMP_FILE}
if [ $ARGNUM -ne 4 ] 
  then
	echo "Usage:  $0  FILE TEMP_FILE NUM T_NUM"
	exit 0
fi
	cat /dev/null > $TMP_FILE
	if [ -r ${FILE} ]
	  then
		i=$T_NUM
		while (( $i <= $T_NUM ))
		do
		   if [[ -n $(tail -n 2000 $FILE|grep "`date --date="$i minutes ago" +"%Y-%m-%d %H:%M"`") ]]
		    then
                      /bin/sed -n -r "/`date --date="$i minutes ago" +"%Y-%m-%d %H:%M"`/,/^$/p" $FILE  |grep -Ei "Memcache连接超时异常" >> $TMP_FILE
		      break
		   fi
		   if [ $i == '0' ]
		    then
			break
		   fi
		
		   i=$((i-1))   
		done
		if [ -s $TMP_FILE ]&&[ `wc -l $TMP_FILE|awk '{print $1'}` -ge $NUM ]
		  then
			head -3 $TMP_FILE
		elif [ -w $TMP_FILE ]
		  then
			echo "SYSLOG_CHECK_OK"
		else
			echo "check_error"
		fi
	else
		echo "check_error"
	fi
