#!/bin/bash
File=$1
FILENAME=`basename $File`
cat /dev/null > /usr/local/zabbix/tmp/$FILENAME.tmp
cd /usr/local/zabbix/script
if [ -r $File ]
then
i=0
while (( $i < 10 ));do
date=`date --date="$i minutes ago" +%-d-%b-%Y::%R`
sed -n -r "/ERROR REPORT.*$date/,/^$/p" $File >> /usr/local/zabbix/tmp/$FILENAME.tmp
i=$((i+1))
done
	if [ -s /usr/local/zabbix/tmp/$FILENAME.tmp ]
           then
           head -5 /usr/local/zabbix/tmp/$FILENAME.tmp
           else
           echo "SYSLOG_CHECK_OK"
        fi
else
   echo "check_error"
fi

