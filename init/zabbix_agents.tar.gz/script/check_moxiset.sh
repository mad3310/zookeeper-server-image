#!/bin/bash
IP=$1
PORT=$2

while true
do 
  TIME=`date +'%Y%m%d%H%M%S'`
  printf "set NOC_$TIME 0 10 14\r\n${TIME}\r\n" | nc -n -w 2 $IP $PORT  > /dev/null 2>/tmp/SetErr.log
#  echo NOC_$TIME ${TIME}
  sleep 0.8
done 
