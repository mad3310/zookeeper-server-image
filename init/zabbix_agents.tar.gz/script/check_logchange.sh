#!/bin/bash
File=$1
FILENAME=`basename $1`
cd /usr/local/zabbix/script
if [ -s $File ] 
	then
	if [ -s $FILENAME.tmp ] && [ -r $File ] 
		then 
			md5sum1=`md5sum $File|awk '{print $1}'`
			md5sum2=`cat /usr/local/zabbix/script/$FILENAME.tmp`
				if [ $md5sum1 == $md5sum2 ]
					then
						echo $md5sum1  > /usr/local/zabbix/script/$FILENAME.tmp
						echo "SYSLOG_CHECK_OK"
					else
						echo $md5sum1  > /usr/local/zabbix/script/$FILENAME.tmp
						cat /dev/null > /tmp/logchange_${FILENAME}
						i=0
						while (( $i < 10 ));do
						tail -2000 ${File} | grep "`date --date="$i minutes ago" "+%Y-%m-%d %H:%M"`"| grep -Evi "MOXI_SASL_PLAIN_USR|MOXI_SASL_PLAIN_PWD" >> /tmp/logchange_${FILENAME}
						i=$((i+1))
						done
					if [ -s /tmp/logchange_${FILENAME} ] 
						then
						head -5 /tmp/logchange_${FILENAME}
						else
						echo "SYSLOG_CHECK_OK"
                                                fi
					fi
		else
			md5sum1=`md5sum $File|awk '{print $1}'`
                        echo $md5sum1  > /usr/local/zabbix/script/$FILENAME.tmp
                        echo "SYSLOG_CHECK_FAILD"
		fi
	else  
	echo "SYSLOG_CHECK_OK"
fi
