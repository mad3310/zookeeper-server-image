#!/bin/sh
FILE=$1
KEY_WORD=$2
EXCLUDE_KEY_WORD=$3
ARGNUM=$#
if [ $ARGNUM -ne 3 ] 
  then
	echo "Usage:    $0  FILE KEY_WORD EXCLUDE_KEY_WORD"
	exit 0
fi
cat /dev/null > /tmp/$FILE.check

if [ -r /var/log/glusterfs/$FILE ]
  then
	i=0
	while (( $i < 10 ));do
	tail -10000 /var/log/glusterfs/$FILE | grep "`date --date="$i minutes ago" +"%F %H:%M"`" | grep -Ei "$KEY_WORD" |grep -Evi "$EXCLUDE_KEY_WORD"  >> /tmp/$FILE.check
	i=$((i+1))
	done
	
	if [ -s /tmp/$FILE.check ]
	   then
		head -5 /tmp/$FILE.check
	elif [ -f  /tmp/$FILE.check ]
	   then
		echo "SYSLOG_CHECK_OK"
	else
		echo "check_error"
	fi
else
	echo "File Permission denied"
fi
