#!/bin/sh
TRIGGER=$1
PERCENT=$2
CPU_NUM=`/usr/local/zabbix/bin/zabbix_get -s 127.0.0.1 -k system.cpu.num 2>/dev/null`
CPU_FREQ_MAX=`sudo /usr/sbin/dmidecode -s   processor-frequency|grep -Ev "Unknown"|sort|uniq|awk '{print $1}'`
for ((i=0;i<$CPU_NUM;i++))
do
CPU_IDLE=`/usr/local/zabbix/bin/zabbix_get -s 127.0.0.1 -k system.cpu.util[$i,idle,avg15] 2>/dev/null`
if [ $(echo "${CPU_IDLE} < ${TRIGGER}" | bc) = 1 ]
   then
    A=$(($i+1))
   CPU_FREQ_CURR=`cat /proc/cpuinfo |grep 'cpu MHz'|sed -n ${A}p|awk '{print $NF}'`       
   CPU_FREQ_PERC=`echo "scale=3;${CPU_FREQ_CURR}/${CPU_FREQ_MAX}"|bc`
    if [ $(echo "${CPU_FREQ_PERC} < ${PERCENT}" | bc) = 1 ]
       then
       echo 1                        
       exit
   fi
fi
done
echo 0

