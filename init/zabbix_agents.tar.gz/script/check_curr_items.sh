#!/bin/bash
HOSTNAME=$1
cd /usr/local/zabbix/tmp
rm -f /usr/local/zabbix/tmp/curr_items.txt
wget --http-user=admin -SO /usr/local/zabbix/tmp/curr_items.txt  --http-passwd="letv(bas3" "http://$HOSTNAME:8091/pools/default/buckets/ark/nodes/$HOSTNAME%3A8091/stats?_=1403086605292&haveTStamp=1403086639522&resampleForUI=1&zoom=minute"
curr_items=`cat /usr/local/zabbix/tmp/curr_items.txt  |perl -ne 'print $1 if /\"curr_items\":\[(\d+),/'`
echo "$curr_items"
