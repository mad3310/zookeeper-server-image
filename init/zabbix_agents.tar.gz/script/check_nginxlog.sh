#!/bin/sh
FILE=$1
KEY_WORD=$2
EXCLUDE_KEY_WORD=$3
NUM=$4
NUM_5=$5
ARGNUM=$#
if [ $ARGNUM -ne 5 ] 
then
echo "Usage:  $0  FILE KEY_WORD EXCLUDE_KEY_WORD NUM400 NUM500"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/nginxlogcheck_${FILE}
if [ -r /var/log/nginx/${FILE} ]
then
i=0
while (( $i < 6 ));do
tail -200000 /var/log/nginx/${FILE} | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Ei "${KEY_WORD}" | grep -Eiv "${EXCLUDE_KEY_WORD}"  >> /tmp/nginxlogcheck_${FILE}
i=$((i+1))
done
if [ -s /tmp/nginxlogcheck_${FILE} ]&&[ `cat /tmp/nginxlogcheck_${FILE}|grep -ic "HTTP/1...4"` -ge $NUM ]
then
cat /tmp/nginxlogcheck_${FILE} | grep -i "HTTP/1...4" | head -3
elif [ -s /tmp/nginxlogcheck_${FILE} ]&&[ `cat /tmp/nginxlogcheck_${FILE}|grep -ic "HTTP/1...5"` -ge $NUM_5 ]
then
cat /tmp/nginxlogcheck_${FILE} | grep -i "HTTP/1...5" | head -3
elif [ -w  /tmp/nginxlogcheck_${FILE} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi

