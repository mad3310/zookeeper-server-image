#!/bin/sh
FILE=$1
NUM_4=$2
NUM_5=$3
ARGNUM=$#
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:    $0  FILE NUM_4 NUM_5"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/varnishlog_check1.log
cat /dev/null > /tmp/varnishlog_check2.log
if [ -r ${FILE} ]
then
i=0
while (( $i < 10 ));do
tail -200000 ${FILE} | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" |grep "HTTP/1... [4-5]" >> /tmp/varnishlog_check1.log
i=$((i+1))
done

if [ -r /tmp/varnishlog_check1.log ]
then
cat /tmp/varnishlog_check1.log|grep "HTTP/1... 4"|grep -Eiv "http://player.letvcdn.com/p.*player/zhuzhan/ HTTP|http://[1-9].*HTTP/1... 4|HEAD|POST|~ET|Baiduspider|http://www.letv.com/cooperation/(360|jj)/ HTTP|http://www.letv.com/@\[ad_3click\]|undefined HTTP/1... 404"|awk '$7 !~ /%|ptv\/(play|vplay|pplay)\/$|v_xml|pchannel|vchannel|(ha|json|ht|htm|html|txt|fws|php|asp|mdb|rar|zip|htc|exe|=)$|[0-9]$/{print $0}'|awk '$11 !~ /""|"-"/{print $0}'|awk '$11 ~/letv.com/{print $0}' >> /tmp/varnishlog_check2.log

if [ -s /tmp/varnishlog_check2.log ]&&[ `wc -l /tmp/varnishlog_check2.log|awk '{print $1'}` -ge $NUM_4 ]||[ `cat /tmp/varnishlog_check1.log|grep -ic "HTTP/1... 5"` -ge $NUM_5 ]
then
head -3 /tmp/varnishlog_check2.log
cat /tmp/varnishlog_check1.log | grep -i "HTTP/1... 5" | head -1
echo Error4: `cat /tmp/varnishlog_check2.log|wc -l` and Error5: `cat /tmp/varnishlog_check1.log | grep -i "HTTP/1... 5"|wc -l`
elif [ -w  /tmp/varnishlog_check1.log ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi
fi
