#!/bin/sh
PORT=$1
PRO=`sudo /usr/sbin/ss -lpn|grep ":$1 "|awk '{print $NF}'|awk -F "," '{ for (i=2; i<=NF; i=i+3) print $i }'|xargs|sed 's/ /|/g'`
if [ -z $PRO ]
  then
     echo "0"
  else
    USER=`ps -eo user,pid|grep -Ew "$PRO"|awk '{print $1}'|sort|uniq|xargs`
    if [[ $USER == "root" ]]
       then
          echo "1"
       else
          echo "0"
     fi
fi 
