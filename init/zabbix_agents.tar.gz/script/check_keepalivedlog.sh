#!/bin/sh

KEY_WORD=$1
/bin/mkdir -p /usr/local/zabbix/tmp
MSG_TMP=/usr/local/zabbix/tmp/keepalived_check.tmp
MSG_LOG=/usr/local/zabbix/tmp/keepalived_check.log
cat /dev/null > $MSG_TMP
cat /dev/null > $MSG_LOG

if [ -f /var/log/messages ]
   then
	sudo /usr/bin/tail -1 /var/log/messages >/dev/null 2>&1
	RST=$?
	if [ "$RST" -ne 0 ]
	  then
		echo "sudo_error"
	else
		TIME0=`date --date="0 minutes ago" +%b" "%e" "%H:%M`
                TIME1=`date --date="1 minutes ago" +%b" "%e" "%H:%M`
                TIME2=`date --date="2 minutes ago" +%b" "%e" "%H:%M`
                TIME3=`date --date="3 minutes ago" +%b" "%e" "%H:%M`
                TIME4=`date --date="4 minutes ago" +%b" "%e" "%H:%M`
                TIME5=`date --date="5 minutes ago" +%b" "%e" "%H:%M`
                TIME6=`date --date="6 minutes ago" +%b" "%e" "%H:%M`
                TIME7=`date --date="7 minutes ago" +%b" "%e" "%H:%M`
                TIME8=`date --date="8 minutes ago" +%b" "%e" "%H:%M`
                TIME9=`date --date="9 minutes ago" +%b" "%e" "%H:%M`
                sudo /usr/bin/tail -100000 /var/log/messages|grep -E "$TIME0|$TIME1|$TIME2|$TIME3|$TIME4|$TIME5|$TIME6|$TIME7|$TIME8|$TIME9" >> $MSG_TMP
		cat $MSG_TMP | grep -Ei "$KEY_WORD" >> $MSG_LOG
		if [ -s $MSG_LOG ]
		  then
			head -5 $MSG_LOG
		else
			echo "SYSLOG_CHECK_OK"
		fi
	fi
else
	echo "file not exist"
fi
