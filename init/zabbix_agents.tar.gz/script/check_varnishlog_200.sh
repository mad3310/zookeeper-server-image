#!/bin/sh
KEY_WORD=$1
EXCLUDE_KEY_WORD=$2
NUM=$3
ARGNUM=$#
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:    $0  KEY_WORD	EXCLUDE_KEY_WORD"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/varnishlog_200.log
if [ -r /var/log/varnish/access.log ]
then
i=0
while (( $i < 5 ));do
tail -20000 /var/log/varnish/access.log | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" |grep -Ei "$KEY_WORD" |grep -Eiv "$EXCLUDE_KEY_WORD" >> /tmp/varnishlog_200.log
i=$((i+1))
done

if [ -s /tmp/varnishlog_200.log ]&&[ `wc -l /tmp/varnishlog_200.log|awk '{print $1'}` -ge $NUM ]
then
head -3 /tmp/varnishlog_200.log
elif [ -w  /tmp/varnishlog_200.log ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi

