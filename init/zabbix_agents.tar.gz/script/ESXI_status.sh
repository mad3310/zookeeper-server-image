#!/bin/bash
IP=$1
zabbix_ip=$2
#Uptime=`snmpwalk -t1 -r2 -c letv-snmp -v2c $IP HOST-RESOURCES-MIB::hrSystemUptime.0 2>/dev/null|awk -F "(" '{print $2}'|awk -F")" '{print $1}' 2>/dev/null`
#/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k check.esxi.uptime -o $Uptime  >/dev/null 2>&1
cd /usr/local/zabbix/script
cat /dev/null > $IP.esxilog
./resxtop.sh $IP > $IP.esxilog
sed -i '1,2d' $IP.esxilog
Load1=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Cpu.*Load.*\(1 Minute Avg\)/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Load5=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Cpu.*Load.*\(5 Minute Avg\)/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Load15=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Cpu.*Load.*\(15 Minute Avg\)/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Cpu_total=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Physical.*Cpu\(_Total\).*Util.*Time/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Mem_total=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Machine.*MBytes/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Mem_free=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Memory.Free.*MBytes/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`
Mem_usedp=`echo "scale=2;(1 - $Mem_free/$Mem_total)*100"|bc`
Swap_used=`awk -F"," 'NR==1{for(i=1;i<=NF;i++)if($i ~ /Swap.Used.MBytes/) a=i} {print $a}'  $IP.esxilog|tail -1|tr -d "\""`

/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k system.cpu.load[,avg1] -o $Load1  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k system.cpu.load[,avg5] -o $Load5  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k system.cpu.load[,avg15] -o $Load15  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k system.cpu.util -o $Cpu_total  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k vm.memory.size[total] -o $Mem_total >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k vm.memory.size[free] -o $Mem_free  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k vm.memory.size[usdp] -o $Mem_usedp  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k system.swap.size[,used] -o $Swap_used  >/dev/null 2>&1

#echo "load1:$Load1"
#echo "load5:$Load5"
#echo "load15:$Load15"
#echo "Cpu_total:$Cpu_total"
#echo "Mem_total:$Mem_total"
#echo "Mem_free=:$Mem_free"
#echo "Mem_usedp=:$Mem_usedp"
#echo "Swap_used:$Swap_used"

size=`du -sk $IP.esxilog |awk '{print $1}'`
if [ $size -gt 100 ]
then 
echo 1
else 
echo 0
fi
