#!/bin/sh
FILE=$1
KEY_WORD=$2
NUM=$3
ARGNUM=$#
FILENAME=`basename $1`
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:  $0  FILE KEY_WORD NUM"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
   then
	cat /dev/null > /tmp/resinlogcheck_${FILENAME}
	    if [ -r ${FILE} ]
	       then
		 i=0
		 while (( $i < 10 ));do
		 tail -20000 ${FILE} | grep -E "^`date --date="$i minutes ago" +%H:%M`|^\[`date --date="$i minutes ago" +%H:%M`" | grep -Ei "${KEY_WORD}"   >> /tmp/resinlogcheck_${FILENAME}
		 i=$((i+1))
		 done
	         if [ -s /tmp/resinlogcheck_${FILENAME} ]&&[ `wc -l /tmp/resinlogcheck_${FILENAME}|awk '{print $1'}` -ge $NUM ]
		   then
		       head -3 /tmp/resinlogcheck_${FILENAME}
		 elif [ -w  /tmp/resinlogcheck_${FILENAME} ]
		   then
		       echo "SYSLOG_CHECK_OK"
		 else
		       echo "check_error"
		 fi
	     else
		echo "check_error"
	     fi
else
	echo "check_error"
fi

