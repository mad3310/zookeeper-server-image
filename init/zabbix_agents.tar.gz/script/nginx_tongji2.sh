#/bin/sh
file=$1
num=$2
code=$3
cat /dev/null > /usr/local/zabbix/tmp/nginx_tongji2.log
i=0
while (( $i < 10 ));do
grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" $file >> /usr/local/zabbix/tmp/nginx_tongji2.log
i=$((i+1))
done
CODE_NUM=`awk '$"'$num'" != "'$code'"{print $0}'  /usr/local/zabbix/tmp/nginx_tongji2.log|wc -l`
echo $CODE_NUM

