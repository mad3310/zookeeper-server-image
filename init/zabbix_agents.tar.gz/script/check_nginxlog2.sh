#!/bin/sh
FILE=$1
KEY_WORD=$2
EXCLUDE_KEY_WORD=$3
NUM=$4
ARGNUM=$#
DIRNAME=`dirname $1|awk -F / '{print $NF}'`
FILENAME=`basename $1`
Uname=`uname`
if [ "$FILE" = "" ] || [ "$KEY_WORD" = "" ] || [ "$EXCLUDE_KEY_WORD" = "" ] || [ "$NUM" = "" ] 
then
echo "script error"
elif [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/nginxlogcheck_${DIRNAME}_${FILENAME}
if [ -r ${FILE} ]
then
i=0
while (( $i < 10 ));do
tail -20000 ${FILE} | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Ei "${KEY_WORD}" | grep -Ev "${EXCLUDE_KEY_WORD}" >> /tmp/nginxlogcheck_${DIRNAME}_${FILENAME}
i=$((i+1))
done
if [ -s /tmp/nginxlogcheck_${DIRNAME}_${FILENAME} ]&&[ `wc -l /tmp/nginxlogcheck_${DIRNAME}_${FILENAME}|awk '{print $1'}` -ge $NUM ]
then
head -3 /tmp/nginxlogcheck_${DIRNAME}_${FILENAME}
elif [ -w  /tmp/nginxlogcheck_${DIRNAME}_${FILENAME} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "file_read_error"
fi
else
echo "OS_error"
fi

