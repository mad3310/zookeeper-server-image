#/bin/sh
IP=$1
zabbix_ip=$2
port=$3
time=$4
result=`/usr/bin/nc -w $4 $IP $port && echo ok || echo fail`
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k check.port -o $result  >/dev/null 2>&1
RST=$?
if [ "$RST" -eq 0 ]
then
echo 0 
else
echo 1
fi
