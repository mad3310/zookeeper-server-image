#!/bin/bash
export PATH=/usr/local/jdk1.6.0_33/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/local/zabbix/bin
cd /usr/local/zabbix/tmp
>/usr/local/zabbix/tmp/QOS.log
curl "http://115.182.94.72/qos.txt" > /usr/local/zabbix/tmp/QOS.txt
while read qos	url platform platid platform1 splatid remarks 
do 
QOS_GET=`curl Is -s  "$url" 2>1 | grep -o -P "qos=\d"|cut -d"=" -f2`
if [ "$qos" == "$QOS_GET" ]
   then 
     check_OK
   else
      echo "$qos $QOS_GET $platform $platform1 $remarks " >> /usr/local/zabbix/tmp/QOS.log
fi 
done < /usr/local/zabbix/tmp/QOS.txt
cat /usr/local/zabbix/tmp/QOS.log
