#!/bin/sh
HOSTNAME="$1"
PROXY_IP="$2"
DATA_FILE=/usr/local/zabbix/tmp/ad_tracking.txt
LOG_FILE=/usr/local/zabbix/tmp/ad_tracking.log
TMP_FILE=/usr/local/zabbix/tmp/ad_tracking.tmp
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
cd /letv/scripts/
TRACKING=`/letv/scripts/tracking.sh|awk '/-/{print $0}'`

if [ `echo $TRACKING|grep -c "-"` -ge 1 ]
  then
        echo Tracking_Script_Error,$TRACKING
else
	/letv/scripts/tracking.sh|grep -Ev [a-zA-Z]|grep 8080|sed -e "s#^#${HOSTNAME} tracking_#g" -e "s#:#_#g" > $TMP_FILE
	cat $TMP_FILE|awk '{print $1,$2"_QPS",$3}' >> $DATA_FILE
	cat $TMP_FILE|awk '{print $1,$2"_RESPONSE_TIME",$4}' >> $DATA_FILE
	cat $TMP_FILE|awk '{print $1,$2"_NO200_COUNT",$5}' >> $DATA_FILE
	cat $TMP_FILE|awk '{print $1,$2"_NO200_RATIO",$6}' >> $DATA_FILE
	cat $TMP_FILE|awk '{print $1,$2"_200_COUNT",$7}' >> $DATA_FILE

        if [[ -s $DATA_FILE ]]
	   then
  		/usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  		Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  		if [ $Failed -eq 1 ]
     		    then
       			echo "OK"
     		else 
       			echo "`cat $LOG_FILE|grep Failed`"
        	fi
	else
    		echo "Error"
	fi
fi
