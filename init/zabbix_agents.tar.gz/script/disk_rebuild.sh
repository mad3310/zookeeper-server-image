#!/bin/sh
TYPE_RAID=`/sbin/lspci |grep -E "RAID|SAS"|awk -F":" '{print $3}'|sed 's/^[[:space:]]*//'`
if [ `echo $TYPE_RAID|grep -c Mega` -eq 1 ]
    then
	A=`sudo /usr/sbin/megacli64 -pdlist -aALL -NoLog |grep -ic "Rebuild"`
	if [ $A = 0 ]
	   then
	     echo OK
	   else
	     echo $A
        fi
   elif [ `echo $TYPE_RAID|grep -c Hewlett-Packard` -eq 1 ]
    then
       slotnum=`sudo /usr/sbin/hpacucli ctrl all show status|grep -i "in Slot" |awk '{print $NF}'`
       PD_NUM=`sudo /usr/sbin/hpacucli ctrl slot=$slotnum pd all show status|grep "physicaldrive"|grep -ic "Rebuilding"`
	 if [ $PD_NUM = 0 ]
	   then
             echo OK
           else 
             echo $PD_NUM
         fi
     else
           echo not_match
fi
