#!/bin/sh
FILE=$1
KEY_WORD=$2
NUM=$3
ARGNUM=$#
if [ $ARGNUM -ne 3 ]
then
echo "Usage:  $0  FILE KEY_WORD EXCLUDE_KEY_WORD NUM400"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /usr/local/zabbix/tmp/nginx_cdnpic_logcheck_${FILE}
if [ -r /var/log/nginx/${FILE} ]
then
i=0
while (( $i < 6 ));do
tail -200000 /var/log/nginx/${FILE} | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Ei "${KEY_WORD}"    >> /usr/local/zabbix/tmp/nginx_cdnpic_logcheck_${FILE}
i=$((i+1))
done
if [ -s /usr/local/zabbix/tmp/nginx_cdnpic_logcheck_${FILE} ]&&[ `cat /usr/local/zabbix/tmp/nginx_cdnpic_logcheck__${FILE}|grep -ic "$KEY_WORD"` -ge $NUM ]
then
cat /usr/local/zabbix/tmp/nginx_cdnpic_logcheck_${FILE} | grep -Ei "$KEY_WORD"
elif [ -w  /usr/local/zabbix/tmp/nginx_cdnpic_logcheck_${FILE} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi
