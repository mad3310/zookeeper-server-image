#!/bin/sh
KEY_WORD=$1
NUM=$2
ARGNUM=$#
if [ $ARGNUM -ne 2 ] 
then
echo "Usage:    $0  KEY_WORD"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/squidlog_check.log
if [ -r /usr/local/squid/var/logs/access.log ]
then
i=0
while (( $i < 10 ));do
tail -2000 /usr/local/squid/var/logs/access.log | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Eiv "TCP_DENIED.403.*GET http://phone.letv.com/clientapi/android22/ent/list/start/0/num/20|TCP_MISS.404.*GET http://www.letv.com/.*html -|TCP_MISS.404.*GET .http://www.letv.com/.*html..text/html"|TCP_MISS.404.*Spider|grep -Ei "$KEY_WORD"  >> /tmp/squidlog_check.log
i=$((i+1))
done
elif [ -r /letv/log/squid_access_log.txt ]
then
i=0
while (( $i < 10 ));do
tail -2000 /letv/log/squid_access_log.txt | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" | grep -Eiv "TCP_DENIED.403.*GET http://phone.letv.com/clientapi/android22/ent/list/start/0/num/20|TCP_MISS.404.*GET http://www.letv.com/.*html -|TCP_MISS.404.*GET .http://www.letv.com/.*html..text/html"|TCP_MISS.404.*Spider|grep -Ei "$KEY_WORD"  >> /tmp/squidlog_check.log
i=$((i+1))
done
else
echo "check_error"
exit
fi
if [ -s /tmp/squidlog_check.log ]&&[ `wc -l /tmp/squidlog_check.log|awk '{print $1'}` -ge $NUM ]
then
head -5 /tmp/squidlog_check.log
elif [ -w  /tmp/squidlog_check.log ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi

