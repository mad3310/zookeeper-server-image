#!/bin/bash
DB=115.182.93.118
DATE1=`date +%F`
LENGTH=1
DATE2=`date --date="$DATE1 -$LENGTH days" +%F`
#echo $STARTDATE
TIME=`date +%s -d $DATE2`


NUM=`/usr/bin/mysql -uz_read -pzRjktn0FjvPH7dXchzse -h$DB zabbix -Ne "SET names utf8;select distinct h.host from hosts as h,items as i where h.hostid=i.hostid and h.status=0 and h.maintenance_status=0 and i.status=0 and i.lastclock < $TIME and (i.type=0 or i.type=3 or i.type=7) and i.key_ not like 'log%';"|wc -l`

echo $NUM


