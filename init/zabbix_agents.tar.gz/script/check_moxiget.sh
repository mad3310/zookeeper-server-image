#!/bin/bash
IP=$1
PORT=$2
while true
do
#echo `date +'%Y%m%d%H%M%S'`
 TIME1=`date +'%Y%m%d%H%M%S' -d '-3 seconds'`
 TIME2=`date +'%Y%m%d%H%M%S' -d '-15 seconds'`
 A=`printf "get NOC_${TIME1}\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "NOC_${TIME1}|END"|sed 's/\r//g'` >/dev/null 2>/tmp/GetErr.log
 B=`printf "get NOC_${TIME2}\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "NOC_${TIME2}|END"|sed 's/\r//g'` >/dev/null 2>/tmp/GetErr.log
# echo A=$A
# echo B=$B
 if [ -z "$A" ]
 then 
     echo `date +"%Y/%m/%d %H:%M:%S"`  "get_key 3s error" >> /tmp/get_key.log
 fi 
 if [ -n "$B" ]
 then
     echo `date +"%Y/%m/%d %H:%M:%S"` "get_key 15s error" >> /tmp/get_key.log 
 fi 
 
sleep 0.8
done 

