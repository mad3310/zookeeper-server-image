#!/bin/bash
IPP=$1
zabbix_ip=$2
IP=$3
PORT=$4
ID=`/sbin/ifconfig -a|grep cast|head -1|awk '{print $2}'|cut -d":" -f2`
NUM=`date +%s`
i=0
#STATUS="set_key_ok"
cat /dev/null > /tmp/cbaseset.log
while (( $i < 10 ));do
A=$(($NUM+$i))
#echo $A
printf "set LETV_NOC_check.$ID.$i 0 0 10\r\n$A\r\n" | nc -n -w 2 $IP $PORT > /dev/null
B=`printf "get LETV_NOC_check.$ID.$i\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "LETV_NOC_check.$ID.$i|END"|sed 's/\r//g'`
if [ -z ${B} ] || [ ${B} -ne ${A} ]
then
echo "set_key_err SetKEY:LETV_NOC_check.$ID.$i Value:$A GetKEY Value:$B;" >> /tmp/cbaseset.log
fi
i=$((i+1))
done

i=41
start1=`date +%s`
while (( $i < 100 ));do
D=cbase-check-noc-$i
printf "set cbase-check-noc-$i 0 0 10\r\n$D\r\n" | nc -n -w 2 $IP $PORT > /dev/null
i=$((i+1))
done
end1=`date +%s`

i=11
start2=`date +%s`
while (( $i < 100 ));do
C=`printf "get cbase-check-noc-$i\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "VALUE cbase-check-noc-$i|END"|sed 's/\r//g'`
if [ -z ${C} ] || [ ${C} != cbase-check-noc-${i} ]
then
echo "get_key_err GetKEY:cbase-check-noc-${i} Value:$C;" >> /tmp/cbaseset.log
fi
i=$((i+1))
done
end2=`date +%s`

setkeytime=`expr $end1 - $start1`
getkeytime=`expr $end2 - $start2`
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IPP  -k setkeytime -o $setkeytime  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IPP  -k getkeytime -o $getkeytime  >/dev/null 2>&1

if [ -s /tmp/cbaseset.log ]
then
cat /tmp/cbaseset.log|xargs
else
echo "set_key_ok"
fi

