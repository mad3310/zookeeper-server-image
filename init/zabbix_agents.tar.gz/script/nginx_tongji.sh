#/bin/sh
IP=$1
zabbix_ip=$2
file=$3
cat /dev/null > /tmp/nginx_tongji.log
i=1
while (( $i < 9 ));do
grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" $file >> /tmp/nginx_tongji.log
i=$((i+1))
done
NUM=`awk '{{if($9 == 403 || $10 == 403 || $11 == 403){code403++;}else if($9 == 404 || $10 == 404 || $11 == 404){code404++;}else if($9 == 502 || $10 == 502 || $11 == 502){code502++;}else if($9 == 504 || $10 == 504 || $11 == 504){code504++;}else if($9 == 302 || $10 == 302 || $11 == 302){code302++;}else if($9 == 500 || $10 == 500 || $11 == 500){code500++;}else if($9 == 503 || $10 == 503 || $11 == 503){code503++;}else if($9 == 200 || $10 == 200 || $11 == 200){code200++;}else if($9 == 406 || $10 == 406 || $11 == 406){code406++;}}}END{print code403","code404","code502","code504","code302","code500","code503","code200","code406}' /tmp/nginx_tongji.log`

CODE403=`echo $NUM|awk -F , '{if($1=="") print "0";else print $1}'`
CODE404=`echo $NUM|awk -F , '{if($2=="") print "0";else print $2}'`
CODE502=`echo $NUM|awk -F , '{if($3=="") print "0";else print $3}'`
CODE504=`echo $NUM|awk -F , '{if($4=="") print "0";else print $4}'`
CODE302=`echo $NUM|awk -F , '{if($5=="") print "0";else print $5}'`
CODE500=`echo $NUM|awk -F , '{if($6=="") print "0";else print $6}'`
CODE503=`echo $NUM|awk -F , '{if($7=="") print "0";else print $7}'`
CODE200=`echo $NUM|awk -F , '{if($8=="") print "0";else print $8}'`
CODE406=`echo $NUM|awk -F , '{if($9=="") print "0";else print $9}'`

/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code403 -o $CODE403  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code404 -o $CODE404  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code502 -o $CODE502  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code504 -o $CODE504  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code302 -o $CODE302  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code500 -o $CODE500  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code503 -o $CODE503  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code200 -o $CODE200  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k nginx.code406 -o $CODE406  >/dev/null 2>&1
size=`du -sk /tmp/nginx_tongji.log |awk '{print $1}'`
if [ $size -gt 1000 ]
then 
echo 1
else 
echo 0
fi
