#!/bin/sh
HOSTNAME=$1
PROXY_IP=$2
DATA_FILE=/tmp/check_infor.txt
LOG_FILE=/tmp/check_infor.log
cat /dev/null > $LOG_FILE
########Device INFORMATION##################
#SN=`sudo /usr/sbin/dmidecode |sed -n '/System Information/,/Serial Number/p'|grep "Serial Number:"|cut -d":" -f2|tr -d " "`
SN=`sudo /usr/sbin/dmidecode -s system-serial-number|sed 's/^[[:space:]]*//'`
if [ -z "$SN" -o "SN" = " " ]
then
echo "$HOSTNAME SN Unknown" > $DATA_FILE
else
echo "$HOSTNAME SN $SN" > $DATA_FILE
fi
Manufacturer=`sudo /usr/sbin/dmidecode -s system-manufacturer`
if [ -z "$Manufacturer" -o "$Manufacturer" = " " ]
then
echo "$HOSTNAME Manufacturer Unknown" >> $DATA_FILE
else
echo "$HOSTNAME Manufacturer $Manufacturer" >> $DATA_FILE
fi
Product=`sudo /usr/sbin/dmidecode -s system-product-name`
if [ -z "$Product" -o "$Product" = " " ]
then
echo "$HOSTNAME Product Unknown" >> $DATA_FILE
else
echo "$HOSTNAME Product $Product" >> $DATA_FILE
fi
UUID=`sudo /usr/sbin/dmidecode -s system-uuid` 
if [ -z "$UUID" -o "$UUID" = " " ]
then
echo "$HOSTNAME UUID Unknown" >> $DATA_FILE
else
echo "$HOSTNAME UUID $UUID" >> $DATA_FILE
fi

########CPU INFORMATION####################
Manufacturer_CPU=`cat /proc/cpuinfo |grep "model name"|sort|uniq|cut -d":" -f2`
if [ `echo $Manufacturer_CPU|grep -ci intel` -eq 1 ]
   then
   echo "$HOSTNAME Manufacturer_CPU Intel" >> $DATA_FILE
#   FRE_CPU=`echo $Manufacturer_CPU|awk '{print $NF}'`
#   echo "$HOSTNAME FRE_CPU $FRE_CPU" >> $DATA_FILE
   elif [ `echo $Manufacturer_CPU|grep -ci AMD` -eq 1 ]
   then
   echo "$HOSTNAME Manufacturer_CPU AMD" >> $DATA_FILE
#   FRE_CPU=`cat /proc/cpuinfo |grep "cpu MHz"|sort|uniq|cut -d":" -f2|tr -d " "`
#   echo "$HOSTNAME FRE_CPU $FRE_CPU" >> $DATA_FILE
   else
   echo "$HOSTNAME Manufacturer_CPU Unknown" >> $DATA_FILE
#   echo "$HOSTNAME FRE_CPU Unknown" >> $DATA_FILE
   fi
FRE_CPU=`sudo /usr/sbin/dmidecode -s   processor-frequency|grep -Ev "Unknown"|sort|uniq`
if [ -z "$FRE_CPU" ]
then
echo "$HOSTNAME FRE_CPU `cat /proc/cpuinfo |grep "cpu MHz"|sort|uniq|cut -d":" -f2|tr -d " "`" >> $DATA_FILE
else
echo "$HOSTNAME FRE_CPU $FRE_CPU" >> $DATA_FILE
fi
Model_CPU=`cat /proc/cpuinfo |grep "model name"|sort|uniq|cut -d":" -f2|sed -e 's/^ AMD Opteron(TM)//' -e 's/Intel(R).*CPU//' -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//'|awk -F "@" '{print $1}'`
echo "$HOSTNAME Model_CPU $Model_CPU" >> $DATA_FILE
NUM_CPU=`cat /proc/cpuinfo |grep "physical id"|sort|uniq|wc -l`
echo "$HOSTNAME NUM_CPU $NUM_CPU" >> $DATA_FILE
NUM_CORE=`cat /proc/cpuinfo |grep "core id"|sort|uniq |wc -l`
echo "$HOSTNAME NUM_CORE $NUM_CORE" >> $DATA_FILE
##########MEMORY  INFORMATION##################
#sudo /usr/sbin/dmidecode |sed -n '/Memory Device/,/System Boot Information/p'|grep -E "^[[:space:]]Size:|^[[:space:]]Manufacturer:|^[[:space:]]Serial Number:|^[[:space:]]Speed:|^[[:space:]]Type:"|grep -Ev "Not Installed|Not Specified|No Module Installed|Configured Clock Speed|Unknown" > /tmp/memory.txt
sudo /usr/sbin/dmidecode -t memory|grep -E "^[[:space:]]Size:|^[[:space:]]Manufacturer:|^[[:space:]]Serial Number:|^[[:space:]]Speed:|^[[:space:]]Type:"|grep -Ev "Not Installed|Not Specified|No Module Installed|Configured Clock Speed|Unknown|Type: DIMM|None|:$|: *$" > /tmp/memory.txt
grep Size /tmp/memory.txt|awk -F":" '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/memory_Size.txt
grep Manufacturer /tmp/memory.txt|awk -F":" '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/memory_Manufacturer.txt
grep "Serial Number" /tmp/memory.txt|awk -F":" '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/memory_SN.txt
grep Speed /tmp/memory.txt|awk -F":" '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/memory_Speed.txt
grep Type /tmp/memory.txt|awk -F":" '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/memory_Type.txt

Size_MEM=`cat /tmp/memory_Size.txt|sort|uniq`
Manufacturer_MEM=`cat /tmp/memory_Manufacturer.txt|grep -vi "Manufacturer"|sort|uniq`
Speed_MEM=`cat /tmp/memory_Speed.txt|sort|uniq`
Type_MEM=`cat /tmp/memory_Type.txt|sort|uniq`
SN_MEM=`cat /tmp/memory_SN.txt|grep -Evi "SerNum|00000000"|sort|uniq|xargs`

if [ `cat /tmp/memory_Size.txt|sort|uniq|wc -l` -eq 1 ] && [ `cat /tmp/memory_Manufacturer.txt|grep -vi "Manufacturer"|sort|uniq|wc -l` -eq 1 ] && [ `cat /tmp/memory_Speed.txt|sort|uniq|wc -l` -eq 1 ] && [ `cat /tmp/memory_Type.txt|sort|uniq|wc -l` -eq 1 ]
then
echo "$HOSTNAME Size_MEM $Size_MEM" >> $DATA_FILE
    if [ -n "$Manufacturer_MEM" ]
       then
           echo "$HOSTNAME Manufacturer_MEM $Manufacturer_MEM" >> $DATA_FILE
       else
           echo "$HOSTNAME Manufacturer_MEM Unknown" >> $DATA_FILE
       fi
echo "$HOSTNAME Speed_MEM $Speed_MEM" >> $DATA_FILE
echo "$HOSTNAME Type_MEM $Type_MEM" >> $DATA_FILE
echo "$HOSTNAME SN_MEM $SN_MEM" >> $DATA_FILE 
echo "$HOSTNAME NUM_MEM `cat /tmp/memory_SN.txt|grep -Evi "SerNum|00000000"|wc -l`" >> $DATA_FILE
else
echo "$HOSTNAME Size_MEM Unknown" >> $DATA_FILE
echo "$HOSTNAME Manufacturer_MEM Unknown" >> $DATA_FILE
echo "$HOSTNAME Speed_MEM Unknown" >> $DATA_FILE
echo "$HOSTNAME Type_MEM Unknown" >> $DATA_FILE
echo "$HOSTNAME SN_MEM Unknown" >> $DATA_FILE
echo "$HOSTNAME NUM_MEM Unknown" >> $DATA_FILE
fi
##########RAID INFORMATION##################
TYPE_RAID=`/sbin/lspci |grep -E "RAID|SAS"|awk -F":" '{print $3}'|sed 's/^[[:space:]]*//'`
NUM_RAID=`echo  $TYPE_RAID|wc -l|awk '{print $1}'`
echo "$HOSTNAME TYPE_RAID $TYPE_RAID" >> $DATA_FILE
echo "$HOSTNAME NUM_RAID $NUM_RAID" >> $DATA_FILE
if [ `echo $TYPE_RAID|grep -c Mega` -eq 1 ]
then
sudo /usr/sbin/megacli64  -cfgdsply -aALL -NoLog |grep -E "Raw Size:|Inquiry Data:|Serial No:" > /tmp/raid_disk.txt
SN_RAID=`cat /tmp/raid_disk.txt|grep "Serial No:"|awk -F":" '{print $2}'`
cat /tmp/raid_disk.txt|grep "Raw Size:" > /tmp/raid_disk_raw.txt
NUM_DISKTYPE=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|wc -l`
if [ -z "$SN_RAID" -o "$SN_RAID" = " " ]
   then 
   echo "$HOSTNAME SN_RAID Unknown" >> $DATA_FILE
   else
   echo "$HOSTNAME SN_RAID $SN_RAID" >> $DATA_FILE
fi
echo "$HOSTNAME NUM_DISKTYPE $NUM_DISKTYPE" >> $DATA_FILE
	if [ $NUM_DISKTYPE -eq 1 ]
           then 
               NUM1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|awk '{print $4,$5}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
        elif [ $NUM_DISKTYPE -eq 2 ]
            then
                NUM1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|head -1|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|head -1|awk '{print $4,$5}'`
                NUM2_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|tail -1|awk '{print $1}'`
               Size2_DISK=`cat /tmp/raid_disk_raw.txt|sort -k3 -n|uniq -c|tail -1|awk '{print $4,$5}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK $NUM2_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK $Size2_DISK" >> $DATA_FILE
         else
               echo "$HOSTNAME NUM1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
         fi
elif [ `echo $TYPE_RAID|grep -c SAS` -eq 1 ]
then
   echo "$HOSTNAME SN_RAID Unknown" >> $DATA_FILE
sudo /usr/bin/lsiutil -p1 -a21,2,0,0,0|grep "PhysDisk Size" > /tmp/raid_disk_raw.txt
   NUM_DISKTYPE=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|wc -l`
   echo "$HOSTNAME NUM_DISKTYPE $NUM_DISKTYPE" >> $DATA_FILE
          if [ $NUM_DISKTYPE -eq 1 ]
           then
               NUM1_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|awk '{print $4,$5}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
        elif [ $NUM_DISKTYPE -eq 2 ]
            then
                NUM1_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|head -1|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|head -1|awk '{print $4,$5}'`
                NUM2_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|tail -1|awk '{print $1}'`
               Size2_DISK=`cat /tmp/raid_disk_raw.txt|awk '{print $1,$2,$3,$4}'|tr -d ","|sort -k3 -n|uniq -c|tail -1|awk '{print $4,$5}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK $NUM2_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK $Size2_DISK" >> $DATA_FILE
         else
               echo "$HOSTNAME NUM1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
         fi
elif [ `echo $TYPE_RAID|grep -c Hewlett-Packard` -eq 1 ]
then           
   SN_RAID=`sudo /usr/sbin/hpacucli ctrl slot=1 show detail|grep -E "^[[:space:]]*Serial Number"|awk '{print $NF}'`
   echo "$HOSTNAME SN_RAID $SN_RAID" >> $DATA_FILE
   sudo /usr/sbin/hpacucli ctrl slot=1 physicaldrive all  show detail|grep "Size" > /tmp/raid_disk_raw.txt
   NUM_DISKTYPE=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|wc -l`
   echo "$HOSTNAME NUM_DISKTYPE $NUM_DISKTYPE" >> $DATA_FILE
          if [ $NUM_DISKTYPE -eq 1 ]
           then
               NUM1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|awk '{print $3,$4}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
         elif [ $NUM_DISKTYPE -eq 2 ]
            then
                NUM1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|head -1|awk '{print $1}'`
               Size1_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|head -1|awk '{print $3,$4}'`
                NUM2_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|tail -1|awk '{print $1}'`
               Size2_DISK=`cat /tmp/raid_disk_raw.txt|sort -k2 -n|uniq -c|tail -1|awk '{print $3,$4}'`
               echo "$HOSTNAME NUM1_DISK $NUM1_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK $Size1_DISK" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK $NUM2_DISK" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK $Size2_DISK" >> $DATA_FILE
         else
               echo "$HOSTNAME NUM1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
         fi
else
	       echo "$HOSTNAME SN_RAID Unknown" >> $DATA_FILE
	       echo "$HOSTNAME NUM_DISKTYPE Unknown" >> $DATA_FILE
               echo "$HOSTNAME NUM1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size1_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME NUM2_DISK Unknown" >> $DATA_FILE
               echo "$HOSTNAME Size2_DISK Unknown" >> $DATA_FILE
fi

sed -i 's/[[:space:]]*$//' $DATA_FILE
if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
