#!/bin/sh
cd /usr/local/zabbix/tmp/
rm -f dell.disktmp hp1.disktmp hp2.disktmp
TYPE_RAID=`/sbin/lspci |grep -E "RAID|SAS"|awk -F":" '{print $3}'|sed 's/^[[:space:]]*//'`
if [ `echo $TYPE_RAID|grep -c Mega` -eq 1 ]
   then
     max_size=`sudo /usr/sbin/megacli64 -AdpAllInfo -aALL -NoLog | grep "Max Strip Size" | cut -d ":" -f2-4`
    if [ `df -P /letv/fet|grep -c sdb` -eq 1 ]
      then
     real_size=`sudo /usr/sbin/megacli64 -LDInfo -L1 Aall -NoLog | grep -Ei "Strip Size" |cut -d ":" -f2-4`
     Mem_size=`sudo /usr/sbin/megacli64 -AdpAllInfo -aALL -NoLog| grep "Memory Size"| cut -d ":" -f2-4`
     sudo /usr/sbin/megacli64 -LDInfo -L1 Aall -NoLog | grep -Ei "Strip Size|State|Current Cache Policy|Disk Cache Policy" > /usr/local/zabbix/tmp/dell.disktmp
    else
     real_size=`sudo /usr/sbin/megacli64 -LDInfo -L0 Aall -NoLog | grep -Ei "Strip Size" |cut -d ":" -f2-4`
     sudo /usr/sbin/megacli64 -LDInfo -L0 Aall -NoLog | grep -Ei "Strip Size:|State:|Current Cache Policy:|Disk Cache Policy:" > /usr/local/zabbix/tmp/dell.disktmp
    fi
      if [ "$max_size" == "$real_size" ]
	then
             if  [ "$Mem_size" == " 0MB" ]
                  then
                   if [ `grep -Ewv "Optimal|$max_size|WriteThrough|Enabled" /usr/local/zabbix/tmp/dell.disktmp |wc -l` -ne 0 ]
                     then
                       grep -Ewv "Optimal|$max_size|WriteThrough|Enabled" /usr/local/zabbix/tmp/dell.disktmp
                     else
                      echo 'check_OK'
                   fi
          else
	if [ `grep -Ewv "Optimal|$max_size|WriteBack, ReadAhead, Cached, Write Cache OK if Bad BBU|Enabled" /usr/local/zabbix/tmp/dell.disktmp |wc -l` -ne 0 ]
	   then 
		grep -Ewv "Optimal|$max_size|WriteBack, ReadAhead, Cached, Write Cache OK if Bad BBU|Enabled" /usr/local/zabbix/tmp/dell.disktmp
	   else 
		echo 'check_OK' 
	 fi
        fi
	 else
	    grep -Ewv "Optimal|$max_size|WriteBack, ReadAhead, Cached, Write Cache OK if Bad BBU|Enabled" /usr/local/zabbix/tmp/dell.disktmp   
        fi 
elif [ `echo $TYPE_RAID|grep -c 'Hewlett-Packard'` -eq 1 ]
     then
       slotnum=`sudo /usr/sbin/hpacucli ctrl all show status|grep -i "in Slot" |awk '{print $NF}'`
       sudo /usr/sbin/hpacucli ctrl slot=$slotnum show config detail | grep -Ei "Strip Size:|Caching:" | tail -2  > /usr/local/zabbix/tmp/hp1.disktmp
       sudo /usr/sbin/hpacucli ctrl slot=$slotnum show config detail | grep -Ei "Cache Ratio:|Degraded Performance Optimization:|No-Battery Write Cache:|Cache Status:|Drive Write Cache:" > /usr/local/zabbix/tmp/hp2.disktmp
     if [ `echo $TYPE_RAID|grep -c 'Smart Array Gen8 Controllers'` -eq 1 ]
	then
	 if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 1024 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
	   then
	   cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 1024 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
	   else
		echo 'check_OK'  
       fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 5.14'` -eq 1 ]
	 then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK| Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
           then
	    cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp | awk '$0 !~/Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK| Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
           else
		echo 'check_OK' 
          fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 2.50'` -eq 1 ]
        then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 64 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]   
	    then 
	    cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 64 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
	    else
		echo 'check_OK'
          fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 3.00'` -eq 1 ]
        then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 64 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
            then
            cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 64 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Disabled|No-Battery Write Cache: Disabled/{print $0}'
              else
                echo 'check_OK'
          fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 5.70'` -eq 1 ]
        then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
            then
            cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
               else
                echo 'check_OK'
          fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 6.40'` -eq 1 ]
        then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 512 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
            then
            cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 512 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
               else
                echo 'check_OK'
          fi
      elif [ `cat /proc/scsi/scsi|tail -2|grep -c 'Rev: 6.00'` -eq 1 ]
        then
          if [ `cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'|wc -l` -ne 0 ]
            then
            cat /usr/local/zabbix/tmp/hp1.disktmp /usr/local/zabbix/tmp/hp2.disktmp |  awk '$0 !~/ Strip Size: 256 KB|Caching:  Enabled|Degraded Performance Optimization: Disabled|Cache Status: OK|Cache Ratio: 70% Read \/\ 30% Write|Drive Write Cache: Enabled|No-Battery Write Cache: Enabled/{print $0}'
               else
                echo 'check_OK'
          fi
      else
        echo 'HP new'
       fi
else
echo 'not match'
fi
