#!/bin/bash
HOSTNAME=$1
PROXY_IP=$2
FILE=$3
PORT=$4
cd /usr/local/zabbix/tmp
TXT_FILE=/usr/local/zabbix/tmp/qps.txt
TMP_FILE=/usr/local/zabbix/tmp/qps.tmp
LOG_FILE=/usr/local/zabbix/tmp/qps.log
cat /dev/null > /usr/local/zabbix/tmp/qps.txt
cat /dev/null > /usr/local/zabbix/tmp/qps.tmp
cat /dev/null > /usr/local/zabbix/tmp/qps.log
$FILE |grep $PORT |sed  's/\//_/g' >  $TXT_FILE
if [[ -s $TXT_FILE ]]
then
while read SERVERIP QPS RESPONSE_TIME NO200_COUNT NO200_RATIO COUNT_200 REQUEST 
do
QPS=`cat qps.txt| grep -w "$REQUEST" | awk '{print $2}'`
RESPONSE_TIME=`cat qps.txt| grep -w "$REQUEST" | awk '{print $3}'`
NO200_COUNT=`cat qps.txt| grep -w "$REQUEST" | awk '{print $4}'`
NO200_RATIO=`cat qps.txt| grep -w "$REQUEST" | awk '{print $5}'`
COUNT_200=`cat qps.txt| grep -w "$REQUEST" | awk '{print $6}'`
echo "$HOSTNAME "$REQUEST"_QPS $QPS" >> $TMP_FILE
echo "$HOSTNAME "$REQUEST"_RESPONSE_TIME $RESPONSE_TIME" >> $TMP_FILE
echo "$HOSTNAME "$REQUEST"_NO200_COUNT $NO200_COUNT" >> $TMP_FILE
echo "$HOSTNAME "$REQUEST"_NO200_RATIO $NO200_RATIO" >> $TMP_FILE
echo "$HOSTNAME "$REQUEST"_COUNT_200 $COUNT_200" >> $TMP_FILE
done < qps.txt
else
  echo check_error
fi
        if [[ -s $TMP_FILE ]]
	   then
  		/usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $TMP_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  		Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  		if [ $Failed -eq 1 ]
     		    then
       			echo "OK"
     		else 
       			echo "`cat $LOG_FILE|grep Failed`"
        	fi
          fi
