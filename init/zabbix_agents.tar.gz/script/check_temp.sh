#!/bin/sh
KEY=$1
HOST=$2
PROXY=$3
sudo /usr/bin/ipmitool sdr type Temperature 2>/dev/null > /usr/local/zabbix/tmp/check.temp.txt
TEMP=`cat /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "$KEY"|awk -F '|' '{print $NF}'|awk '{print $1}'|sort -rn|head -1`
TEMP_TYPE=`cat /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "CPU|Exhaust|Ambient"|cat /usr/local/zabbix/tmp/check.temp.txt|grep 'degrees C'|grep -Ei "$KEY"|awk -F '|' '{print $NF,$1}'|sort -k1 -rn|grep -Ei "CPU|Exhaust|Ambient"|head -1|cut -d" " -f5-`
/usr/local/zabbix/bin/zabbix_sender -z $PROXY -s $HOST  -k TEMP_TYPE -o "$TEMP_TYPE"  >/dev/null 2>&1
echo "$TEMP"
