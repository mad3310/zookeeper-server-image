#!/bin/sh
Path=/usr/local/zabbix/script
IP=$1
PORT=$2
KEY=$3
cd $Path
if [ -z `find ./ -name cbase_$PORT -mmin +3` ] && [ -s $Path/cbase_$PORT ]
then
cat  $Path/cbase_$PORT | grep "$KEY" | awk '{print $3}'
else
printf "stats\r\n" | nc -i 1 -n -w 5 $IP $PORT > cbase_$PORT
cat  $Path/cbase_$PORT | grep "$KEY" | awk '{print $3}'
fi
