#!/bin/bash
HOST=$1
PROXY=$2
LOG_FILE=/usr/local/zabbix/tmp/check_zhuanma.log
CHECK_FILE=/usr/local/zabbix/tmp/check_zhuanma.txt
cd /usr/local/zabbix/tmp/
>$LOG_FILE
>$CHECK_FILE
curl -s "http://115.182.94.145:20018/encodeTimeout" >zhuanma.tmp
sed "s#^#$HOST #g" zhuanma.tmp > $CHECK_FILE
if [[ -s $CHECK_FILE ]]
 then 
 /usr/local/zabbix/bin/zabbix_sender -z $PROXY -i $CHECK_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
  then 
       echo "OK"
     else
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"

fi
