#!/bin/sh
HOST=$1
PROXY_IP=$2
DATA_FILE=/usr/local/zabbix/tmp/namenode.txt
LOG_FILE=/usr/local/zabbix/tmp/namenode.log
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
for KEY in CLOUD YINGSHIKU SOCIAL mini 2013 LIVENEW
do
    if [ `cat /usr/local/zabbix/tmp/namenode_2.tmp|grep -c "$KEY"` -eq 1 ]       
       then
        echo "$HOST $KEY `cat /usr/local/zabbix/tmp/namenode_2.tmp|grep "$KEY"|awk '{print $1}'`" >> $DATA_FILE
     else
        echo "$HOST $KEY 0" >> $DATA_FILE
    fi
done 
cat /usr/local/zabbix/tmp/namenode_2.tmp|grep -w /data1/video/ > /usr/local/zabbix/tmp/namenode_all.tmp
  A=`cat $DATA_FILE|awk '{print $NF}'|xargs|sed 's/ /-/g'`
  B=`cat /usr/local/zabbix/tmp/namenode_all.tmp|awk '{print $1}'`
  C=$(($B-$A))
  echo "$HOST  video $C" >> $DATA_FILE  

cat $DATA_FILE|sed -e 's/CLOUD/CLOUD_TOTAL/' -e 's/YINGSHIKU/YINGSHIKU_TOTAL/' -e 's/SOCIAL/SOCIAL_TOTAL/' -e 's/mini/mini_TOTAL/' -e 's/ 2013 / 2013_TOTAL /' -e 's/LIVENEW/LIVENEW_TOTAL/' -e's/video/video_TOTAL/' > /usr/local/zabbix/tmp/namenode.temp

for KEY in CLOUD_TOTAL YINGSHIKU_TOTAL SOCIAL_TOTAL mini_TOTAL 2013_TOTAL LIVENEW_TOTAL video_TOTAL
do
   NUM=`cat /usr/local/zabbix/tmp/namenode.temp|grep $KEY|awk '{print $NF}'`
   echo "$HOST $KEY ${NUM}" >> $DATA_FILE
done

df -kP /data1|tail -1 > /usr/local/zabbix/tmp/namenode.temp

echo "$HOST TOTAL_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|awk '{print $2}'`" >> $DATA_FILE
echo "$HOST Remaining_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|awk '{print $4}'`" >> $DATA_FILE
echo "$HOST Used_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|awk '{print $3}'`" >> $DATA_FILE


if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
