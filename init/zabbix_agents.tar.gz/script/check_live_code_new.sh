#!/bin/sh
cd /usr/local/zabbix/tmp
HOSTNAME=$1
PROXY_IP=$2
TAIL_NUM=$3
DATA_FILE=/usr/local/zabbix/tmp/live_code.txt
LOG_FILE=/usr/local/zabbix/tmp/live_code.temp
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
tail -${TAIL_NUM} /letv/ngxlog/access.log > /usr/local/zabbix/tmp/live_code.log
TOTAL_NUM=`wc -l /usr/local/zabbix/tmp/live_code.log|awk '{print $1}'`
if [ $TOTAL_NUM -gt 100 ]
then
for code in 400 403 502 416 500 504 503 404 
do
if [[ $code != 416 ]] && [[ $code != 403 ]]
then
grep -w " $code"  /usr/local/zabbix/tmp/live_code.log  > $code
live=`wc -l $code|awk '{print $1}'`
live_new=`grep -w " $code"  /usr/local/zabbix/tmp/live_code.log|grep "live_2_0_0_1"|wc -l|awk '{print $1}'`
live_new1=`grep -w " $code" /usr/local/zabbix/tmp/live_code.log|grep -v "live_2_0_0_1"|wc -l|awk '{print $1}'`
live_RATE=`echo "scale=2;${live}*100/${TOTAL_NUM}"|bc`
live_RATE_new=`echo "scale=2;${live_new}*100/${TOTAL_NUM}"|bc`
live_RATE_new1=`echo "scale=2;${live_new1}*100/${TOTAL_NUM}"|bc`
echo "$HOSTNAME live${code}_RATE_total ${live_RATE}" >> $DATA_FILE
echo "$HOSTNAME live${code}_RATE ${live_RATE_new}" >> $DATA_FILE
echo "$HOSTNAME live2.0_${code}_RATE ${live_RATE_new1}" >> $DATA_FILE
else
grep -w " $code"  /usr/local/zabbix/tmp/live_code.log|grep -v "GStreamer souphttpsrc libsoup"  > $code
live=`wc -l $code|awk '{print $1}'`
live_RATE=`echo "scale=2;${live}*100/${TOTAL_NUM}"|bc`
echo "$HOSTNAME live${code}_RATE ${live_RATE}" >> $DATA_FILE
fi
done
if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
else
echo "less then 100"
fi
