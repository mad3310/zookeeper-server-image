#!/bin/sh
KEY_WORD=$1
ARGNUM=$#
if [ $ARGNUM -ne 1 ] 
  then
	echo "Usage:    $0  KEY_WORD"
	exit 0
fi
/bin/mkdir -p /usr/local/zabbix/tmp
MSG_TMP=/usr/local/zabbix/tmp/message_check.tmp
MSG_LOG=/usr/local/zabbix/tmp/message_check.log
cat /dev/null > $MSG_TMP
cat /dev/null > $MSG_LOG

Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
 then
	if [ -f /var/log/messages ]
  	  then
		sudo /usr/bin/tail -1 /var/log/messages >/dev/null 2>&1
		RST=$?
		if [ "$RST" -ne 0 ]
	  	  then
			echo "sudo_error"
	        else
			TIME0=`date --date="0 minutes ago" +%b" "%e" "%H:%M`
                        TIME1=`date --date="1 minutes ago" +%b" "%e" "%H:%M`
                        TIME2=`date --date="2 minutes ago" +%b" "%e" "%H:%M`
                        TIME3=`date --date="3 minutes ago" +%b" "%e" "%H:%M`
                        TIME4=`date --date="4 minutes ago" +%b" "%e" "%H:%M`
                        TIME5=`date --date="5 minutes ago" +%b" "%e" "%H:%M`
                        TIME6=`date --date="6 minutes ago" +%b" "%e" "%H:%M`
                        TIME7=`date --date="7 minutes ago" +%b" "%e" "%H:%M`
                        TIME8=`date --date="8 minutes ago" +%b" "%e" "%H:%M`
                        TIME9=`date --date="9 minutes ago" +%b" "%e" "%H:%M`
                        sudo /usr/bin/tail -100000 /var/log/messages | grep -E "$TIME0|$TIME1|$TIME2|$TIME3|$TIME4|$TIME5|$TIME6|$TIME7|$TIME8|$TIME9" >> $MSG_TMP
			cat $MSG_TMP |grep -Ei "$KEY_WORD" | grep -Evi "sudo:   zabbix|watchdog.*segfault.*error 15|libperl.so|perl.*segfault.*libperl.so|segfault.*libudtp.so" >> $MSG_LOG
			if [ -s $MSG_LOG ]
		  	   then
				head -5 $MSG_LOG
			else
				echo "SYSLOG_CHECK_OK"
			fi
		fi
	else
		echo "file not exist"
	fi
else
	if [ -f /var/log/messages ]
	  then
	     	TIME0=`date -v -0M +%b" "%e" "%H:%M`
		TIME1=`date -v -1M +%b" "%e" "%H:%M`
		TIME2=`date -v -2M +%b" "%e" "%H:%M`
		TIME3=`date -v -3M +%b" "%e" "%H:%M`
		TIME4=`date -v -4M +%b" "%e" "%H:%M`
		TIME5=`date -v -5M +%b" "%e" "%H:%M`
		TIME6=`date -v -6M +%b" "%e" "%H:%M`
		TIME7=`date -v -7M +%b" "%e" "%H:%M`
		TIME8=`date -v -8M +%b" "%e" "%H:%M`
		TIME9=`date -v -9M +%b" "%e" "%H:%M`
		tail -10000 /var/log/messages | grep -E "$TIME0|$TIME1|$TIME2|$TIME3|$TIME4|$TIME5|$TIME6|$TIME7|$TIME8|$TIME9" >> $MSG_TMP
		cat $MSG_TMP|grep -Ei "$KEY_WORD" | grep -Evi "watchdog.*segfault.*error 15" >> $MSG_LOG 
		if [ -s $MSG_LOG ]
		  then
			head -5 $MSG_LOG
		else
			echo "SYSLOG_CHECK_OK"
		fi
	else
		echo "file not exist"
	fi
fi
