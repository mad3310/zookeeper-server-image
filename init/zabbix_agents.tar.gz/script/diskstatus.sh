#!/bin/sh
TYPE_RAID=`/sbin/lspci |grep -E "RAID|SAS"|awk -F":" '{print $3}'|sed 's/^[[:space:]]*//'`
if [ `echo $TYPE_RAID|grep -c Mega` -eq 1 ]
    then
	sudo /usr/sbin/megacli64 -AdpAllInfo -aALL -NoLog |grep "Failed Disks"|awk '{print $NF}'
    elif [ `echo $TYPE_RAID|grep -c SAS` -eq 1 ]
    then
       DISK_NUM=`sudo /usr/bin/lsiutil -p1 -a21,2,0,0,0|grep "PhysDisk State:"|grep -vc "online"`
       Volume_NUM=`sudo /usr/bin/lsiutil -p1 -a21,1,0,0,0|grep "Volume State"|grep -Evc "optimal|unknown"`
       if [ $DISK_NUM -ne 0 ] || [ $Volume_NUM -ne 0 ]
          then
            echo "1"
          else
            echo "0"
       fi
    elif [ `echo $TYPE_RAID|grep -c Hewlett-Packard` -eq 1 ]
    then
       slotnum=`sudo /usr/sbin/hpacucli ctrl all show status|grep -i "in Slot" |awk '{print $NF}'`
       LD_NUM=`sudo /usr/sbin/hpacucli ctrl slot=$slotnum ld all show status|grep "logicaldrive"|grep -vc "OK"`
       PD_NUM=`sudo /usr/sbin/hpacucli ctrl slot=$slotnum pd all show status|grep "physicaldrive"|grep -vc "OK"`
       if [ $LD_NUM -ne 0 ] || [ $PD_NUM -ne 0 ]
          then
            echo "1"
          else
            echo "0"
       fi
    elif [ `echo $TYPE_RAID|grep -c 'Adaptec AAC-RAID'` -eq 1 ]
      then
      echo "999"
fi
