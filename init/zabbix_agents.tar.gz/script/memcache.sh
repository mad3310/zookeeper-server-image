#!/bin/sh
Path=/usr/local/zabbix/script
IP=$1
PORT=$2
KEY=$3
cd $Path
if [ -z `find ./ -name memcache_$PORT -mmin +3` ] && [ -s $Path/memcache_$PORT ]
then
cat  $Path/memcache_$PORT | grep "$KEY" | awk '{print $3}'
else
printf "stats\r\n" | nc -i 1 -n -w 5 $IP $PORT > memcache_$PORT
cat  $Path/memcache_$PORT | grep "$KEY" | awk '{print $3}'
fi
