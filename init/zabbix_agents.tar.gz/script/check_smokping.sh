#!/bin/sh
cd /usr/local/zabbix/script
rm -f /usr/local/zabbix/tmp/check.smokeping.*
IP=`GET -t 5 http://mcache.oss.letv.com/smoke/config?type=1|grep slaves|awk -F"=" '{print $2}'|sed -e 's/10.47.0.34//' -e 's/10.47.0.32//'`
function check {
nc -w 1 -z $ip 10050 > /dev/null
RES=$?
if [ $RES -eq 0 ]
then
A=0
B=0
A=`/usr/local/zabbix/bin/zabbix_get -s $ip -k proc.num[,,,"/data/smokeping/bin/smokeping.dist \[EchoPingHttp\]"] 2>/dev/null||sed 's/ZBX_NOTSUPPORTED//' &`
B=`/usr/local/zabbix/bin/zabbix_get -s $ip -k proc.num[,,,"/data/smokeping/bin/smokeping.dist \[FPing\]"] 2>/dev/null||sed 's/ZBX_NOTSUPPORTED//' &`
echo "$ip $A $B" >> /usr/local/zabbix/tmp/check.smokeping.tmp
else 
echo $ip >> /usr/local/zabbix/tmp/check.smokeping.fail
fi
}

function check_again {
RES=`/usr/local/zabbix/bin/zabbix_get -s $PROXY -k check.nc[$ip,10050]`
if [ $RES -eq 0 ]
then
A=0
B=0
A=`/usr/local/zabbix/bin/zabbix_get -s $PROXY -k check.proxy.smokeping1[$ip] 2>/dev/null &`
B=`/usr/local/zabbix/bin/zabbix_get -s $PROXY -k check.proxy.smokeping2[$ip] 2>/dev/null &` 
echo "$ip $A $B" >> /usr/local/zabbix/tmp/check.smokeping.tmp_$PROXY
if [[ $A -lt 1 ]] || [[ $B -lt 1 ]]
then
echo "$ip" >> /usr/local/zabbix/tmp/check.smokeping.fail_$PROXY
fi
else
echo $ip >> /usr/local/zabbix/tmp/check.smokeping.fail_$PROXY
fi
}


tmp_fifofile="$.fifo_smoking"
mkfifo $tmp_fifofile
exec 6<>$tmp_fifofile
rm $tmp_fifofile
thread=100

for ((i=0;i<$thread;i++))
do
echo
done >&6

for ip in $IP
do
read -u6
(check;echo >&6)&
done

wait
exec 6>&-

cat /usr/local/zabbix/tmp/check.smokeping.tmp|awk 'NF != 3{print $1}' >> /usr/local/zabbix/tmp/check.smokeping.fail
cat /usr/local/zabbix/tmp/check.smokeping.tmp|awk 'NF == 3{print $0}' >> /usr/local/zabbix/tmp/check.smokeping.log

while read ip A B
do
if [[ $A -lt 1 ]] || [[ $B -lt 1 ]]
then
echo "$ip" >> /usr/local/zabbix/tmp/check.smokeping.error
fi
done < /usr/local/zabbix/tmp/check.smokeping.log




tmp_fifofile="$.fifo_smoking2"
mkfifo $tmp_fifofile
exec 6<>$tmp_fifofile
rm $tmp_fifofile
thread=100

for ((i=0;i<$thread;i++))
do
echo
done >&6

i=1
for PROXY in 218.206.201.236 114.80.187.245 211.162.59.93
do
nc -w 1 -z $PROXY 10050 > /dev/null
res=$?
if [ $res -eq 0 ]
then
i=$(($i+1))
while read ip
do
read -u6
(check_again;echo >&6)&
done < /usr/local/zabbix/tmp/check.smokeping.fail
fi
done

wait
exec 6>&-

cat /usr/local/zabbix/tmp/check.smokeping.fail*|sort|uniq -c|sort -rn|grep "$i "|awk '{print $2}' >> /usr/local/zabbix/tmp/check.smokeping.error

if [ -s /usr/local/zabbix/tmp/check.smokeping.error ]
then
cat /usr/local/zabbix/tmp/check.smokeping.error|sort
else
check_ok
fi

