#!/bin/sh
PORT=$1
KEY_WORD=$2
ARGNUM=$#
if [ $ARGNUM -ne 2 ] 
then
echo "Usage:  $0  PORT KEY_WORD"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
max_user_processes=`cat /usr/local/zabbix/mysql/theresult_$PORT |grep "max user processes"|awk '{print $5}'`
if [[ $max_user_processes != "" ]]
then
echo "`ps -eLf|grep mysql|wc -l` *100 / ${max_user_processes}"|bc 
else 
echo "`ps -eLf|grep mysql|wc -l` *100 / ${KEY_WORD}"|bc
fi
else
echo "check_error"
fi
