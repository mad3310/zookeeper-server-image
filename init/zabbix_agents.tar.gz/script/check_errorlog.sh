#!/bin/sh
FILE=$1
KEY_WORD=$2
EXCLUDE_KEY_WORD=$3
NUM=$4
ARGNUM=$#
FILENAME=`basename $1`
if [ $ARGNUM -ne 4 ] 
then
echo "Usage:  $0  FILE  KEY_WORD  EXCLUDE_KEY_WORD NUM"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/errorlogcheck_${FILENAME}
if [ -r ${FILE} ]
then
i=0
while (( $i < 10 ));do
tail -20000 ${FILE} | grep "`date --date="$i minutes ago" "+%Y/%m/%d %H:%M"`"| grep -Ei "${KEY_WORD}" |grep -Eiv "${EXCLUDE_KEY_WORD}" >> /tmp/errorlogcheck_${FILENAME}
i=$((i+1))
done
if [ -s /tmp/errorlogcheck_${FILENAME} ]&&[ `wc -l /tmp/errorlogcheck_${FILENAME}|awk '{print $1'}` -ge $NUM ]
then
head -3 /tmp/errorlogcheck_${FILENAME}
elif [ -w  /tmp/errorlogcheck_${FILENAME} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi
