#!/bin/sh
ZABBIX_PROXY=`awk '{print $2}' /usr/local/zabbix/conf/host.temp`
HOST=`awk '{print $1}' /usr/local/zabbix/conf/host.temp`
echo "RECORD CPU% TOP 5" > /usr/local/zabbix/tmp/record_load.log
echo "%CPU USER PID PPID CMD" >> /usr/local/zabbix/tmp/record_load.log
ps -eo %cpu,user,pid,ppid,cmd|sed '1d'|sort -rn|head -5 >> /usr/local/zabbix/tmp/record_load.log
echo "######################" >> /usr/local/zabbix/tmp/record_load.log
echo "RECORD MEM% TOP 5" >> /usr/local/zabbix/tmp/record_load.log
echo "%MEM USER PID PPID CMD" >> /usr/local/zabbix/tmp/record_load.log
ps -eo %mem,user,pid,ppid,cmd|sed '1d'|sort -rn|head -5 >> /usr/local/zabbix/tmp/record_load.log
if [ -s /usr/bin/iotop ]
then
echo "######################" >> /usr/local/zabbix/tmp/record_load.log
echo "RECOED IO% TOP5" >> /usr/local/zabbix/tmp/record_load.log
sudo /usr/bin/iotop -o -b -n 2 -P -d 2|sed '/Total/i\aaaaa'|sed '/^aaaaa$/,/^aaaaa$/d'|head -7 >> /usr/local/zabbix/tmp/record_load.log
fi
A=$(cat /usr/local/zabbix/tmp/record_load.log|awk 'BEGIN{FS="\n";ORS="\\n"}{print $0}'|sed 's#\\n$##g')
echo "$HOST host_trapper \"$A\"" > /usr/local/zabbix/tmp/record_load.txt
/usr/local/zabbix/bin/zabbix_sender -z $ZABBIX_PROXY -i /usr/local/zabbix/tmp/record_load.txt
