#!/bin/bash
Dir=$1
File=`ls -lrt $Dir/error.[0-9]*|tail -1|awk '{print $NF}'`
FILENAME=`basename $File`
cat /dev/null > /usr/local/zabbix/script/$FILENAME.tmp1
cat /dev/null > /usr/local/zabbix/script/$FILENAME.tmp2
cd /usr/local/zabbix/script
if [ -r $File ]
then
i=0
while (( $i < 10 ));do
date=`date --date="$i minutes ago" +"%Y-%m-%d %-H:%M"`
sed -n -r "/error.*$date/,/^$/p" $File >> /usr/local/zabbix/script/$FILENAME.tmp1
i=$((i+1))
done
    if [ -s /usr/local/zabbix/script/$FILENAME.tmp1 ]
      then
       cat /usr/local/zabbix/script/$FILENAME.tmp1|awk '{RS="\n\n+"}{if($0~/leaving cluster|for deletion|went down|didn'\''t respond|Reason:     shutdown|Reason:     couldnt_connect_to_memcached|ns_memcached:terminate|Reason:     killed|Reason:     couldnt_connect_to_memcached|Failed to get stats|Reason:     {shutdown|Some nodes didn/)print}' >> /usr/local/zabbix/script/$FILENAME.tmp2
       if [ -s /usr/local/zabbix/script/$FILENAME.tmp2 ]   
         then
           head -5 /usr/local/zabbix/script/$FILENAME.tmp2
       else
           echo "SYSLOG_CHECK_OK"
       fi
    else
        echo "SYSLOG_CHECK_OK"
    fi
else
   echo "check_error"
fi
