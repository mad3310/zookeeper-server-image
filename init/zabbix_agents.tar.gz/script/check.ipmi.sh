#!/bin/bash
cd /usr/local/zabbix/tmp
file1=/usr/local/zabbix/tmp/ipmi1.txt
file2=/usr/local/zabbix/tmp/ipmi2.txt
file3=/usr/local/zabbix/tmp/diff.txt
not_care=$1
ipmi=`sudo /usr/bin/ipmitool sel 2>/dev/null|grep "Percent Used"|awk '{print $NF}'|tr -d "%"`
sudo /usr/bin/ipmitool sel list 2>/dev/null > $file2 
if [ -s $file1 ]
  then
diff $file1 $file2 |grep ">"|sed -n 's/^>//p'|grep -Eiv "$not_care" > $file3
   if [ $ipmi -ge 80 ]
     then
     sudo /usr/bin/ipmitool sel clear 2>/dev/null
   fi
   if [ -s $file3 ]
     then
      echo "`head -5 $file3`"
     else
      ipmi=`sudo /usr/bin/ipmitool sel 2>/dev/null|grep "Percent Used"|awk '{print $NF}'|tr -d "%"`
      if [ $ipmi -ge 80 ]
       then
        echo "$ipmi"
       else
         echo "Check_OK"
      fi
   fi
  else 
   echo "Check_OK"
fi
mv -f $file2 $file1
