#!/usr/bin/perl
use Shell;
use IO::File;

my($res);

my($servername)=$ARGV[0];
my($dnsname)=$ARGV[1];
my($port)=$ARGV[2];
my($retrytimes)=$ARGV[3];
my($delay)="2";

my($rtt)=-1;
my($i)=1;

while ($rtt==-1 && $i<=3)
{
  #�����Ӧ����
  $res=Shell::dig("\@$servername \+time=$delay \+tries=$retrytimes", $dnsname, "a -p $port");

  @line=split(/\n/, $res);

  #�Ƿ���������


  foreach $k (@line) {
    if((index($k, "Query time:") != -1) && (index($k, "msec") != -1)){
      $pass = substr ( $k, index($k, "Query time:")+11+1,  index($k, "msec") - 1 - index($k, "Query time:")- 11 - 1 );
      $rtt = $pass;	
    }
  }

#  sleep 2;
  $i++;
}

#print "resultflag=10\n";
print "$rtt\n";
#print "status_text=response responsetime=".$rtt."ms\n";

#sub conv {

#  chomp($result);
#  return $result;
#}

exit 0; 
