#!/bin/sh
VIP=`/sbin/ip ad sh eth0|grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/32";/sbin/ip ad sh eth1|grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/32"`
if [ -z "$VIP" ]
then 
  echo "check_ok"
else
  IP=`(sudo /sbin/ipvsadm -ln|grep -E "TCP|UDP"|awk '{print $2}'|awk -F":" '{print $1}'|sort|uniq;/sbin/ip ad sh eth0|grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/32"|awk -F"/" '{print $1}';/sbin/ip ad sh eth1|grep -Eo "[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/32"|awk -F"/" '{print $1}')|sort|uniq -u`
	if [ -z "$IP" ]
	then 
  		echo "check_ok"
	else
	  echo "$IP"   
	fi
fi
