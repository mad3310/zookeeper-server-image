#!/bin/sh
HOST=$1
PROXY_IP=$2
DATA_FILE=/usr/local/zabbix/tmp/namenode.txt
LOG_FILE=/usr/local/zabbix/tmp/namenode.log
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
/usr/local/hadoop/bin/hadoop fs -dus /video/CLOUD  /video/YINGSHIKU /video/LIVENEW /video/SOCIAL /video/mini /video/2013  /video > /usr/local/zabbix/tmp/namenode.tmp
cat /usr/local/zabbix/tmp/namenode.tmp|awk -F '/' '{print $NF}'|sed -e "s/^/${HOST} /g" -e 's/[[:space:]][[:space:]]*/ /g' > /usr/local/zabbix/tmp/namenode.temp
for KEY in CLOUD YINGSHIKU SOCIAL mini 2013 LIVENEW
do
    if [ `cat /usr/local/zabbix/tmp/namenode.temp|grep -c "$KEY"` -eq 1 ]       
       then
        cat /usr/local/zabbix/tmp/namenode.temp|grep "$KEY" >> $DATA_FILE
     else
        echo "$HOST $KEY 0" >> $DATA_FILE
    fi
done 
cat /usr/local/zabbix/tmp/namenode.temp|grep video > /usr/local/zabbix/tmp/namenode_all.tmp
  A=`cat $DATA_FILE|awk '{print $NF}'|xargs|sed 's/ /-/g'`
  B=`cat /usr/local/zabbix/tmp/namenode_all.tmp|awk '{print $NF}'`
  C=$(($B-$A))
  echo "$HOST  video $C" >> $DATA_FILE  

cat $DATA_FILE|sed -e 's/CLOUD/CLOUD_TOTAL/' -e 's/YINGSHIKU/YINGSHIKU_TOTAL/' -e 's/SOCIAL/SOCIAL_TOTAL/' -e 's/mini/mini_TOTAL/' -e 's/ 2013 / 2013_TOTAL /' -e 's/LIVENEW/LIVENEW_TOTAL/' -e's/video/video_TOTAL/' > /usr/local/zabbix/tmp/namenode.temp

for KEY in CLOUD_TOTAL YINGSHIKU_TOTAL SOCIAL_TOTAL mini_TOTAL 2013_TOTAL LIVENEW_TOTAL video_TOTAL
do
   NUM=`cat /usr/local/zabbix/tmp/namenode.temp|grep $KEY|awk '{print $NF}'`
   NUM_2=`expr $NUM \* 2`
   echo "$HOST $KEY ${NUM_2}" >> $DATA_FILE
done

/usr/local/hadoop/bin/hadoop dfsadmin -report > /usr/local/zabbix/tmp/namenode.temp

echo "$HOST TOTAL_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|grep 'Configured Capacity'|awk '{print $3}'`" >> $DATA_FILE
echo "$HOST Remaining_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|grep 'DFS Remaining'|awk '{print $3}'`" >> $DATA_FILE
echo "$HOST Used_Capacity `cat /usr/local/zabbix/tmp/namenode.temp|grep 'DFS Used:'|awk '{print $3}'`" >> $DATA_FILE


if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
