#!/bin/sh
NETIF=$1
TOTAL=`nettop -tn1 -i ${NETIF} | grep total | awk '{print $5}'`
TOTAL_NUM=`echo ${TOTAL}|tr -d "mk"`
TOTAL_UNIT=`echo ${TOTAL}|rev|cut -c1`
#echo ${TOTAL_NUM}
#echo ${TOTAL_UNIT}
if [ ${TOTAL_UNIT} = "m" ]
then
echo "scale=1;${TOTAL_NUM}*1024*1024"|bc
elif [ ${TOTAL_UNIT} = "k" ]
then
echo "scale=1;${TOTAL_NUM}*1024"|bc
else
echo "${TOTAL_NUM}"
fi

