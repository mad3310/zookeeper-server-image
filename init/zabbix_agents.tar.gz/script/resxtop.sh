#!/usr/bin/expect
set IP [lindex $argv 0]
set passwd letv.com
set timeout 25
spawn resxtop --server $IP --username root -b -a  -d 2 -n  3
expect "*password:*"; 
sleep 2;
send -- "$passwd\r"; 
expect eof; 
