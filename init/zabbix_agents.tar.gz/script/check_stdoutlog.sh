#!/bin/sh
FILE=$1
KEY_WORD=$2
NUM=$3
ARGNUM=$#
FILENAME=`basename $1`
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:  $0  FILE KEY_WORD NUM"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
	cat /dev/null > /tmp/check_${FILENAME}
	if [ -r ${FILE} ]
	then
	i=0
	while (( $i < 10 ));do
		/bin/sed -n -r "/`date --date="$i minutes ago" +"%Y-%m-%d %H:%M"`/,/^$/p" $FILE  |grep "$KEY_WORD" >> /tmp/check_${FILENAME}
		i=$((i+1))
	done
	if [ -s /tmp/check_${FILENAME} ]&&[ `wc -l /tmp/check_${FILENAME}|awk '{print $1'}` -ge $NUM ]
		then
			head -3 /tmp/check_${FILENAME}
	elif [ -w /tmp/check_${FILENAME} ]
		then
			echo "SYSLOG_CHECK_OK"
	else
			echo "check_error"
	fi

	else
			echo "file_read_error"
	fi
else
   echo "check_error"
fi
