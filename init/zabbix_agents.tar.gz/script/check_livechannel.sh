#!/bin/bash
HOSTNAME=$1
PROXY_IP=$2
DATA_FILE=/usr/local/zabbix/tmp/check_live.txt
TEMP_FILE=/usr/local/zabbix/tmp/check_live.temp
LOG_FILE=/usr/local/zabbix/tmp/check_live.log
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
cat /dev/null > $TEMP_FILE
/usr/bin/curl http://monitor.admin.live.letv.com:8181/letvmsjson/monitorDataAction'!'monitorStatusPageListtv.do |grep -o -P "flag\":\"\d+\",\"hour\":\d+,\"id\":\"\D+\","|awk -F '"' '{print $9,$3}' >> $TEMP_FILE

/bin/sed "s/^/$HOSTNAME /g" $TEMP_FILE > $DATA_FILE
echo "$HOSTNAME guzhang_total `cat $TEMP_FILE|awk '{print $NF}'|grep -Ewc "4|5"`" >> $DATA_FILE
#echo "$HOSTNAME live_total `awk '{print $1}' $TEMP_FILE|xargs`" >> $DATA_FILE

if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
