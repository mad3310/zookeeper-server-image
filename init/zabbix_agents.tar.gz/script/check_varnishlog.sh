#!/bin/sh
KEY_WORD=$1
EXCLUDE_KEY_WORD=$2
NUM=$3
ARGNUM=$#
if [ $ARGNUM -ne 3 ] 
then
echo "Usage:    $0  KEY_WORD	EXCLUDE_KEY_WORD"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/varnishlog_check1.log
cat /dev/null > /tmp/varnishlog_check.log
if [ -r /var/log/varnish/access.log ]
then
i=0
while (( $i < 10 ));do
tail -200000 /var/log/varnish/access.log | grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" |grep -Ei "$KEY_WORD" |grep -Eiv "$EXCLUDE_KEY_WORD" >> /tmp/varnishlog_check1.log
i=$((i+1))
done

while read line
do
if echo $line |awk '{print $11}'|awk -F / '{print $3}'|grep "letv" > /dev/null
then
echo $line >>/tmp/varnishlog_check.log
fi
done < /tmp/varnishlog_check1.log

if [ -s /tmp/varnishlog_check.log ]&&[ `wc -l /tmp/varnishlog_check.log|awk '{print $1'}` -ge $NUM ]
then
head -5 /tmp/varnishlog_check.log
elif [ -w  /tmp/varnishlog_check.log ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi
