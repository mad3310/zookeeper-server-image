#/bin/sh
Tail_NUM=$1
Alarm_NUM=$2
KEY=$3
CODE=$4
tail -$Tail_NUM /usr/local/letv/access.log |awk -F'"' '$3 ~ /^ ('$CODE')/'|awk -F'"' '{print $6}'|sort|uniq -c|sort -rn|grep -Evi "$KEY|Mozilla|AppleCoreMedia|Android|[0-9]{1,} -$"|head -1 > /usr/local/zabbix/tmp/ua.log
A=`cat /usr/local/zabbix/tmp/ua.log|awk '{print $1}'`
if [ $A -gt $Alarm_NUM ]
  then
  echo "`cat /usr/local/zabbix/tmp/ua.log`"
  else
  echo check_ok
fi
