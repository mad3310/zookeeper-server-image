#!/bin/sh
HOSTNAME="$1"
PROXY_IP="$2"
DATA_FILE=/usr/local/zabbix/tmp/check_ad_cbase.txt
LOG_FILE=/usr/local/zabbix/tmp/check_ad_cbase.log
TMP_FILE=/usr/local/zabbix/tmp/check_ad_cbase.tmp
cat /dev/null > $LOG_FILE
cd /letv/softwares/monitor
if [ `/letv/softwares/monitor/cbase-monitor|grep -c error` -eq 1 ]
then 
   echo "Connect_Error"

else
/letv/softwares/monitor/cbase-monitor|grep -Ev [a-zA-Z]|sed "s#^#${HOSTNAME} #g" > $TMP_FILE

cat $TMP_FILE|awk '{print $1,"connect_times",$2}' > $DATA_FILE
cat $TMP_FILE|awk '{print $1,"get_times",$3}' >> $DATA_FILE
cat $TMP_FILE|awk '{print $1,"get_failure",$4}' >> $DATA_FILE
cat $TMP_FILE|awk '{print $1,"inc_times",$5}' >> $DATA_FILE
cat $TMP_FILE|awk '{print $1,"inc_failure",$6}' >> $DATA_FILE

if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Cbase Monitor Script Return Null"
fi
fi
