#!/bin/sh
cd /usr/local/zabbix/tmp
HOSTNAME=$1
PROXY_IP=$2
TAIL_NUM=$3
DATA_FILE=/usr/local/zabbix/tmp/cdn_code.txt
LOG_FILE=/usr/local/zabbix/tmp/cdn_code.temp
cat /dev/null > $LOG_FILE
cat /dev/null > $DATA_FILE
tail -${TAIL_NUM} /usr/local/letv/access.log|grep -E "platid=|video_type=" > /usr/local/zabbix/tmp/cdn_code.log
TOTAL_NUM=`wc -l /usr/local/zabbix/tmp/cdn_code.log|awk '{print $1}'`
if [ $TOTAL_NUM -gt 1000 ]
then
for code in 400 402 403 408 416 420 499 500 501 502 503 504 601
do
grep -w " $code"  /usr/local/zabbix/tmp/cdn_code.log  > $code
live=`grep -c "tag=live" $code`
CODE=`grep -v "tag=live" $code|awk '{print $6}'|grep -Ec "\..{2,10}\?"`
Other=`grep -v "tag=live" $code|awk '{print $6}'|grep -Evc "\..{2,10}\?"`
live_RATE=`echo "scale=2;${live}*100/${TOTAL_NUM}"|bc`
CODE_RATE=`echo "scale=2;${CODE}*100/${TOTAL_NUM}"|bc`
Other_RATE=`echo "scale=2;${Other}*100/${TOTAL_NUM}"|bc`
echo "$HOSTNAME CODE${code}_RATE ${CODE_RATE}" >> $DATA_FILE
echo "$HOSTNAME live${code}_RATE ${live_RATE}" >> $DATA_FILE
echo "$HOSTNAME Other${code}_RATE ${Other_RATE}" >> $DATA_FILE
done
echo "$HOSTNAME TOTAL_NUM $TOTAL_NUM" >> $DATA_FILE
grep -w " 404"  /usr/local/zabbix/tmp/cdn_code.log  > 404
live=`grep -c "tag=live" 404`
CODE=`grep -v "tag=live" 404|grep -v "owninneragent HIT"|awk '{print $6}'|grep -Ec "\..{2,10}\?"`
CODE_IN=`grep -v "tag=live" 404|grep "owninneragent HIT"|awk '{print $6}'|grep -Ec "\..{2,10}\?"`
NUM=`wc -l 404|awk '{print $1}'`
Other=`expr ${NUM} - ${live} - ${CODE} - ${CODE_IN}`
live_RATE=`echo "scale=2;${live}*100/${TOTAL_NUM}"|bc`
CODE_RATE=`echo "scale=2;${CODE}*100/${TOTAL_NUM}"|bc`
CODE_IN_RATE=`echo "scale=2;${CODE_IN}*100/${TOTAL_NUM}"|bc`
Other_RATE=`echo "scale=2;${Other}*100/${TOTAL_NUM}"|bc`
echo "$HOSTNAME CODE404_RATE ${CODE_RATE}" >> $DATA_FILE
echo "$HOSTNAME CODEIN404_RATE ${CODE_IN_RATE}" >> $DATA_FILE
echo "$HOSTNAME live404_RATE ${live_RATE}" >> $DATA_FILE
echo "$HOSTNAME Other404_RATE ${Other_RATE}" >> $DATA_FILE

grep -w " 401"  /usr/local/zabbix/tmp/cdn_code.log  > 401
live401=`grep -c "tag=live" 401`
CODE401=`grep -v "tag=live" 401|grep -Ev "MSIE.*bytes="|awk '{print $6}'|grep -Ec "\..{2,10}\?"`
NUM401=`wc -l 401|awk '{print $1}'`
Other401=`expr ${NUM401} - ${live401} - ${CODE401}`
live_RATE401=`echo "scale=2;${live401}*100/${TOTAL_NUM}"|bc`
CODE_RATE401=`echo "scale=2;${CODE401}*100/${TOTAL_NUM}"|bc`
Other_RATE401=`echo "scale=2;${Other401}*100/${TOTAL_NUM}"|bc`
echo "$HOSTNAME CODE401_RATE ${CODE_RATE401}" >> $DATA_FILE
echo "$HOSTNAME live401_RATE ${live_RATE401}" >> $DATA_FILE
echo "$HOSTNAME Other401_RATE ${Other_RATE401}" >> $DATA_FILE

if [[ -s $DATA_FILE ]]
then
  /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
  Failed=`cat $LOG_FILE|grep -c "Failed 0"`
  if [ $Failed -eq 1 ]
     then
       echo "OK"
     else 
       echo "`cat $LOG_FILE|grep Failed`"
     fi
else
    echo "Error"
fi
else
echo "less then 1000"
fi 

