#!/bin/sh
/bin/mkdir -p /usr/local/zabbix/tmp
cat /dev/null > /usr/local/zabbix/tmp/openstack_message_check.log
if [ -f /var/log/messages ]; then
    sudo /bin/cat /var/log/messages >/dev/null 2>&1
    RST=$?
        if [ "$RST" -ne 0 ]; then
            echo "sudo_error" 
        else
            i=0
            while (( $i < 10 ));do
            sudo /bin/cat /var/log/messages | grep "`date --date="$i minutes ago" +%b" "%e" "%H:%M`" | grep "kernel" | grep "qemu-kvm" | grep -Ei "Tainte" >> /usr/local/zabbix/tmp/openstack_message_check.log
            sudo /bin/cat /var/log/messages | grep "`date --date="$i minutes ago" +%b" "%e" "%H:%M`" | grep "kernel" | grep "soft lockup" | >> /usr/local/zabbix/tmp/openstack_message_check.log
            i=$((i+1))
            done
                if [ -s /usr/local/zabbix/tmp/openstack_message_check.log ]; then
                    head -5 /usr/local/zabbix/tmp/openstack_message_check.log
                elif [ -f  /usr/local/zabbix/tmp/openstack_message_check.log ]; then
                    echo "SYSLOG_CHECK_OK"
                else
                    echo "check_error"
                fi
        fi
else
    echo "check_error"
fi
