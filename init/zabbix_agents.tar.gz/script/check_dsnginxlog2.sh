#!/bin/sh
FILE=$1
KEY_WORD=$2
NUM=$3
T_NUM=$4
ARGNUM=$#
FILENAME=`basename $1`
if [ $ARGNUM -ne 4 ] 
then
echo "Usage:  $0  FILE KEY_WORD NUM"
exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
cat /dev/null > /tmp/ds2nginxlogcheck_${FILENAME}
if [ -r ${FILE} ]
then
i=0
while (( $i < $T_NUM ));do
tail -20000 ${FILE} |grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`"|awk -F "\"" '{print $8}'|awk -F ":" -v a="$KEY_WORD" '$2>a {print $0}' >> /tmp/ds2nginxlogcheck_${FILENAME}
i=$((i+1))
done
if [ -s /tmp/ds2nginxlogcheck_${FILENAME} ]&&[ `wc -l /tmp/ds2nginxlogcheck_${FILENAME}|awk '{print $1'}` -ge $NUM ]
then
head -3 /tmp/ds2nginxlogcheck_${FILENAME}
elif [ -w  /tmp/ds2nginxlogcheck_${FILENAME} ]
then
echo "SYSLOG_CHECK_OK"
else
echo "check_error"
fi
else
echo "check_error"
fi
else
echo "check_error"
fi

