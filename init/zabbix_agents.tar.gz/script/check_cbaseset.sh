#!/bin/bash
IP=$1
PORT=$2
ID=`/sbin/ifconfig -a|grep cast|head -1|awk '{print $2}'|cut -d":" -f2`
NUM=`date +%s`
i=0
#STATUS="set_key_ok"
cat /dev/null > /tmp/cbaseset.log
while (( $i < 10 ));do
A=$(($NUM+$i))
#echo $A
printf "set LETV_NOC_check.$ID.$i 0 0 10\r\n$A\r\n" | nc -n -w 2 $IP $PORT > /dev/null
B=`printf "get LETV_NOC_check.$ID.$i\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "LETV_NOC_check.$ID.$i|END"|sed 's/\r//g'`
if [ -z ${B} ] || [ ${B} -ne ${A} ]
then
echo "set_key_err SetKEY:LETV_NOC_check.$ID.$i Value:$A GetKEY Value:$B;" >> /tmp/cbaseset.log
fi
i=$((i+1))
done
i=11
while (( $i < 41 ));do
C=`printf "get cbase-check-noc-$i\r\n" | nc -n -w 2 $IP $PORT|grep -Ev "VALUE cbase-check-noc-$i|END"|sed 's/\r//g'`
if [ -z ${C} ] || [ ${C} != cbase-check-noc-${i} ]
then
echo "get_key_err GetKEY:cbase-check-noc-${i} Value:$C;" >> /tmp/cbaseset.log
fi
i=$((i+1))
done
if [ -s /tmp/cbaseset.log ]
then
cat /tmp/cbaseset.log|xargs
else
echo "set_key_ok"
fi

