#!/bin/sh
cd /home/zabbix/bin
export LANG=en_US.UTF-8
HOST=$1
Title=`echo "$2" |cut -d":" -f1|iconv -f UTF8 -t GB2312`
#PHONE=`echo "$1"|grep -o -P "(\d+)"|sort|uniq|xargs`
CONTENT=`echo $3|iconv -f UTF8 -t GB2312`
while read IP PORT PHONE
do
STATUS=`echo $Title|grep -c $PORT`
STATUS2=`echo $Title|grep -Ec "mysqld"` 
P=`echo "$PHONE"|grep -o -P "\d{11}"|sort|uniq|xargs`
if [ "$HOST" == "$IP" ] && [ -n "$P" ] && ( [ ${STATUS} -ne 0 ] || [ ${STATUS2} -ne 0 ] )
then
./Send_sms.sh  "$PHONE" "$Title;$CONTENT" &
fi
done < /home/zabbix/db_sms/ip.txt
