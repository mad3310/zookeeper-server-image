#!/bin/bash
################################
#chk_gro.sh: 检查LVS网卡 关闭GRO
#AUTH:	Qishudong
#Mod:	2013.03.07
################################

ethtool='sudo /usr/sbin/ethtool'
null='/dev/null'
net_file='/etc/udev/rules.d/70-persistent-net.rules'
if  [ -e $net_file ];then
    net_ifs=`perl -ne 'print "$1\n" if /.+ NAME=\"(eth.+)\"/' $net_file`
    key='generic-receive-offload: on'

for net_if in $net_ifs
do
    if $ethtool -k $net_if 2> $null | grep -q "$key"
    then
       err_if="$net_if $err_if"
    fi
done

if  [ -n "$err_if" ]
then
    echo "*** error *** $err_if Gro is on, please turn off."
    exit 1
else
    echo "*** OK *** Gro is turned off."
fi

else
    echo "OK, Gro is turned off."
    exit 0
fi
