#!/bin/bash
cd /usr/local/zabbix/script
volume_list=`sudo /usr/sbin/gluster volume list`
sudo /usr/sbin/gluster volume quota $volume_list list |grep video > /usr/local/zabbix/tmp/volume_list.txt
> /usr/local/zabbix/tmp/namenode_2.tmp
while read a b c
do
num=`echo $c|tr -d "TMKGB"`
if [ `echo "$c" |grep -c TB` -eq 1 ]
then
num_new=`echo $num\*1024\*1024\*1024|bc | awk '{print sprintf("%d", $0);}'`
  echo "$num_new /data1$a/" >>/usr/local/zabbix/tmp/namenode_2.tmp
elif [ `echo "$c" |grep -c GB` -eq 1 ]
then
num_new=`echo $num\*1024\*1024|bc | awk '{print sprintf("%d", $0);}'`
  echo "$num_new /data1$a/" >>/usr/local/zabbix/tmp/namenode_2.tmp
elif [ `echo "$c" |grep -c MB` -eq 1 ]
then
num_new=`echo $num\*1024|bc | awk '{print sprintf("%d", $0);}'`
  echo "$num_new /data1$a/" >>/usr/local/zabbix/tmp/namenode_2.tmp
elif [ `echo "$c" |grep -c KB` -eq 1 ]
then
  echo "$num /data1$a/" >>/usr/local/zabbix/tmp/namenode_2.tmp
else
echo " " 
fi
done < /usr/local/zabbix/tmp/volume_list.txt
