#!/bin/bash
HOST=$1
PROXY=$2
URL=$3
API_SSO_TMP=/usr/local/zabbix/tmp/api_sso.tmp
API_SSO_FILE=/usr/local/zabbix/tmp/api_sso.txt
CHECK_API_SSO_FILE=/usr/local/zabbix/tmp/api_sso.log
cat /dev/null > $API_SSO_TMP
cat /dev/null > $API_SSO_FILE
cat /dev/null > $CHECK_API_SSO_FILE
HTTP=`(time -p curl -Is -S --connect-timeout 3 '$URL'|grep 'HTTP') 2> $API_SSO_TMP`
if [[ `echo $HTTP` == '' ]]
 then
     echo "$HOST API_SSO_HTTP connection_error" > $API_SSO_FILE
     echo "$HOST API_SSO_time `cat $API_SSO_TMP|grep real|awk '{print $2}'`" >> $API_SSO_FILE
  else
     echo "$HOST API_SSO_HTTP $HTTP" > $API_SSO_FILE
     echo "$HOST API_SSO_time `cat $API_SSO_TMP|grep real|awk '{print $2}'`" >> $API_SSO_FILE
fi
if [[ -s $API_SSO_FILE ]]
   then
      /usr/local/zabbix/bin/zabbix_sender -z $PROXY -i $API_SSO_FILE 2>>$CHECK_API_SSO_FILE 1>>$CHECK_API_SSO_FILE
       Failed=`cat $CHECK_API_SSO_FILE|grep -c "Failed 0"`
      if [ $Failed -eq 1 ]
        then
         echo "OK"
        else
         echo "`cat $CHECK_API_SSO_FILE|grep Failed`"
      fi
    else
        echo "not exist"
fi
