#/bin/sh
HOSTNAME=$1
PROXY_IP=$2
FILE=$3
FILENAME=`basename $FILE`
cat /dev/null > /tmp/$FILENAME.tmp
DATA_FILE=/tmp/check_search.txt
LOG_FILE=/tmp/check_search.log
cat /dev/null > $DATA_FILE
cat /dev/null > $LOG_FILE
DATE=`date +"%F %H"`
A1=the_failed_count_of_task
A2=vrsAlbum_the_failed_record_count_for_cbase
A3=vrsAlbum_the_failed_record_count_for_hbase
A4=vrsVideo_the_failed_record_count_for_cbase
A5=vrsVideo_the_failed_record_count_for_hbase
A6=vrsStar_the_failed_record_count_for_cbase
A7=vrsStar_the_failed_record_count_for_hbase
A8=ptvVideo_the_failed_record_count_for_cbase
A9=ptvVideo_the_failed_record_count_for_hbase
A10=lesoAlbum_the_failed_record_count_for_cbase
A11=lesoAlbum_the_failed_record_count_for_hbase
A12=lesoExtranetalbum_the_failed_record_count_for_cbase
A13=iptvVideo_the_failed_record_count_for_cbase
A14=iptvVideo_the_failed_record_count_for_hbase
A15=iptvAlbum_the_failed_record_count_for_cbase
A16=iptvAlbum_the_failed_record_count_for_hbase
A17=iptvStar_the_failed_record_count_for_cbase
A18=iptvStar_the_failed_record_count_for_hbase
A19=the_total_time_of_spending_of_task

if [ -s $FILE ]
then
   /bin/sed -n -r "/$DATE/,/^$/p" $FILE >> /tmp/$FILENAME.tmp
   if [ -s /tmp/$FILENAME.tmp ]
   then
	      	  echo "$HOSTNAME $A1 `grep -w $A1 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A2 `grep -w $A2 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A3 `grep -w $A3 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A4 `grep -w $A4 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A5 `grep -w $A5 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A6 `grep -w $A6 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A7 `grep -w $A7 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A8 `grep -w $A8 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A9 `grep -w $A9 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A10 `grep -w $A10 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A11 `grep -w $A11 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A12 `grep -w $A12 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A13 `grep -w $A13 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A14 `grep -w $A14 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A15 `grep -w $A15 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A16 `grep -w $A16 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A17 `grep -w $A17 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
		  echo "$HOSTNAME $A18 `grep -w $A18 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE
                  echo "$HOSTNAME $A19 `grep -w $A19 /tmp/$FILENAME.tmp|awk '{if($2=="") print "1234567890";else print $2}'`" >> $DATA_FILE

      if [[ -s $DATA_FILE ]]
       then
        /usr/local/zabbix/bin/zabbix_sender -z $PROXY_IP -i $DATA_FILE 2>>$LOG_FILE 1>>$LOG_FILE
        Failed=`cat $LOG_FILE|grep -c "Failed 0"`
        if [ $Failed -eq 1 ]
          then
            echo "OK"
        else 
            echo "`cat $LOG_FILE|grep Failed`"
        fi
      fi
    fi	   
else
    echo "file_error"
fi
