#!/bin/sh
FILE=$1
NUM=$2
ARGNUM=$#
FILENAME=`basename $1`
TMP_FILE=/usr/local/zabbix/tmp/dianshangcheck_${FILENAME}
if [ $ARGNUM -ne 2 ] 
  then
	echo "Usage:  $0  FILE NUM"
	exit 0
fi
Uname=`uname`
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
  then
	cat /dev/null > $TMP_FILE
	if [ -r ${FILE} ]
	  then
		i=0
		while (( $i < 10 ))
		do
			tail -20000 ${FILE} | grep "`date --date="$i minutes ago" +"%m-%d %H:%M"`" | grep -E "Memcache连接超时异常" >> $TMP_FILE
			i=$((i+1))
		done
		if [ -s $TMP_FILE ]&&[ `wc -l $TMP_FILE|awk '{print $1'}` -ge $NUM ]
		  then
			head -3 $TMP_FILE
		elif [ -w $TMP_FILE ]
		  then
			echo "SYSLOG_CHECK_OK"
		else
			echo "check_error"
		fi
	else
		echo "check_error"
	fi
else
	echo "check_error"
fi

