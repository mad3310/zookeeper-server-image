#/bin/sh
IP=$1
zabbix_ip=$2
cat /dev/null > /tmp/varnish_tongji.log
i=1
while (( $i < 9 ));do
#grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" /var/log/varnish/access.log /var/log/varnish/access.log.1|grep -Ev "undefined.HTTP/1....404.*AppleWebKit" >> /tmp/varnish_tongji.log
grep "`date --date="$i minutes ago" +%d/%b/%Y:%R`" /var/log/varnish/access.log /var/log/varnish/access.log.1 >> /tmp/varnish_tongji.log
i=$((i+1))
done
NUM=`awk '{if($7 ~ /www.letv.com\/(v_xml|ptv\/[pv]play\/)/ && $6 !~ /PURGE/) {if($9 == 200){code200++;bw200+=$10}else if($9 == 401) {code401++;}else if($9 == 404) {code404++;}}}END{print code200","bw200","code401","code404}' /tmp/varnish_tongji.log`
CODE200=`echo $NUM|awk -F , '{if($1=="") print "0";else print $1}'`
BW200=`echo $NUM|awk -F , '{if($2=="") print "0";else print $2}'`
CODE401=`echo $NUM|awk -F , '{if($3=="") print "0";else print $3}'`
CODE404=`echo $NUM|awk -F , '{if($4=="") print "0";else print $4}'`
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k varnish.code200 -o $CODE200  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k varnish.bw200 -o $BW200  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k varnish.code401 -o $CODE401  >/dev/null 2>&1
/usr/local/zabbix/bin/zabbix_sender -z $zabbix_ip -s $IP  -k varnish.code404 -o $CODE404  >/dev/null 2>&1
size=`du -sk /tmp/varnish_tongji.log |awk '{print $1}'`
if [ $size -gt 1000 ]
then
echo 1
else
echo 0
fi
