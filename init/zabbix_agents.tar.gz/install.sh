#!/bin/sh
Path=/usr/local/zabbix
Uname=`uname`
########################
#if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
#then
#  Hostname=`/sbin/ifconfig |grep -i cast|grep -i inet|awk '/inet addr/{gsub(/addr./,"");print $2}'|head -1`
#elif [ "$Uname" = "FreeBSD" ]
#then
#  Hostname=`/sbin/ifconfig |grep -i cast|grep -i inet|awk '{print $2}'|head -1`
#else
#  exit 1
#fi
#File=$Path/conf/zabbix_agentd.conf
#for file in $File
#do
#  sed -e"1,\$s/^Hostname=.*/Hostname=$Hostname/g" $File > $File.bak
#  mv $File.bak $File
#done
#for file in $File
#do
#  sed -e"1,\$s/^ListenIP=.*/ListenIP=$Hostname/g" $File > $File.bak
#  mv $File.bak $File
#done
#########################
release=`uname -a`
if [ `echo $release|grep -i "FreeBSD 7"|wc -l` -eq 1 ]
then
tar xfz zabbix_FreeBSD7.tar.gz
elif [ `echo $release|grep -i "FreeBSD 8"|wc -l` -eq 1 ]
then
tar xfz zabbix_FreeBSD8.tar.gz
elif [ `echo $release|grep -i "x86_64"|wc -l` -eq 1 ]
then
tar xzf zabbix_agents_1.8.15.linux2_6.amd64.tar.gz
else 
tar xfz zabbix_agents_1.8.15.linux2_6_23.i386.tar.gz
fi
#########################
if [ "$Uname" = "linux" ] || [ "$Uname" = "Linux" ]
then
  crontab  $Path/crond.zabbix
elif [ "$Uname" = "FreeBSD" ]
then
  crontab  $Path/crond.zabbix.FreeBSD
else
  exit 1
fi
