#!/bin/sh
cd /usr/local/zabbix/conf
if [ -z "`cat zabbix_agentd.conf|grep "Server="|grep 60.28.199.175`" ]
then
cat zabbix_agentd.conf |sed -e "s/^Server=.*/&,60.28.199.175/"|sed -e "s/^# UnsafeUserParameters=0/UnsafeUserParameters=1/g"  > zabbix_agentd.conf.bak
mv zabbix_agentd.conf.bak zabbix_agentd.conf
fi
