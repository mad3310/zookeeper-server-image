#!/bin/sh
export PATH=/sbin:/bin:/usr/sbin:/usr/bin:/usr/games:/usr/local/sbin:/usr/local/bin:/usr/local/zabbix/bin
ps aux|grep zabbix_agentd|grep -v grep > /dev/null
if [ $? -eq 1 ]
  then 
  /usr/local/zabbix/sbin/zabbix_agentd -c /usr/local/zabbix/conf/zabbix_agentd.conf start
  else
     md5sum1=`md5 /usr/local/zabbix/conf/zabbix_agentd.userparams.conf|awk '{print $4}'`
     md5sum2=`cat /usr/local/zabbix/md5sum.tmp`
     md5sum_conf1=`md5 /usr/local/zabbix/conf/zabbix_agentd.conf|awk '{print $4}'`
     md5sum_conf2=`cat /usr/local/zabbix/md5sum_conf.tmp`
     defunct_pro=`ps aux|grep zabbix_agentd | grep defunct | grep -v grep |wc -l`
     if [ $md5sum1 = $md5sum2 -a $md5sum_conf1 = $md5sum_conf2 -a $defunct_pro -eq 0 ]
     then
 	exit
     else
        killall zabbix_agentd
	sleep 5
	kill -9 `ps aux|grep zabbix_agentd|grep -v grep|awk '{print $2}'|xargs`
        /usr/local/zabbix/sbin/zabbix_agentd -c /usr/local/zabbix/conf/zabbix_agentd.conf start
        echo $md5sum1  > /usr/local/zabbix/md5sum.tmp
	echo $md5sum_conf1  > /usr/local/zabbix/md5sum_conf.tmp
     fi
fi
